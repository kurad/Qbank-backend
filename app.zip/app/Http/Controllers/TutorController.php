<?php

namespace App\Http\Controllers;

use App\Models\CourseMaterial;
use App\Models\GradeSubject;
use App\Models\Group;
use App\Models\LearningPeriod;
use App\Models\TutorMessage;
use App\Models\TutorSession;
use App\Models\Unit;
use App\Models\Topic;
use App\Services\GroqAIService;
use App\Services\Tutor\TutorAIService;
use App\Services\Tutor\TutorContextService;
use App\Services\Tutor\TutorSessionService;
use Illuminate\Http\Request;

class TutorController extends Controller
{
    public function __construct(
        protected TutorContextService $context,
        protected TutorSessionService $sessionsService,
        protected TutorAIService $ai
    ) {}

    /**
     * Student's groups/classes.
     */
    public function groups(Request $request)
    {
        return response()->json([
            'data' => $this->context->studentGroups(
                $request->user()
            ),
        ]);
    }

    /**
     * Subjects available to a teacher for assigning learning
     * to a class/group.
     *
     * The teacher does NOT need to be a member of the group.
     */
    public function subjects(
        Request $request,
        Group $group
    ) {
        $user = $request->user();

        abort_unless(
            $user,
            401,
            'Unauthenticated.'
        );

        abort_unless(
            $user->role === 'teacher',
            403,
            'Only teachers can access class subjects.'
        );

        /*
     * A teacher does not need to belong to the class.
     *
     * Return GradeSubjects assigned to this teacher.
     */
        $subjects = GradeSubject::query()
            ->where('teacher_id', $user->id)
            ->where('school_id', $user->school_id)
            ->with([
                'subject:id,name',
                'gradeLevel:id,grade_name',
            ])
            ->orderBy('id')
            ->get();

        return response()->json([
            'data' => $subjects,
        ]);
    }
    public function currentLearningPeriods(
        Request $request,
        Group $group
    ) {
        return response()->json([
            'data' => $this->context->currentLearningPeriods(
                $request->user(),
                $group
            ),
        ]);
    }

    /**
     * All published learning periods for the group.
     */
    public function learningPeriods(
        Request $request,
        Group $group
    ) {
        return response()->json([
            'data' => $this->context->learningPeriodsForStudent(
                $request->user(),
                $group,
                false
            ),
        ]);
    }

    /**
     * Topics scheduled inside a specific learning period.
     */
    public function learningPeriodTopics(
        Request $request,
        Group $group,
        LearningPeriod $learningPeriod
    ) {
        return response()->json([
            'data' => $this->context->learningPeriodTopics(
                $request->user(),
                $group,
                $learningPeriod
            ),
        ]);
    }

    /**
     * Legacy curriculum endpoint.
     */
    public function units(
        Request $request,
        Group $group,
        GradeSubject $gradeSubject
    ) {
        return response()->json([
            'data' => $this->context->units(
                $request->user(),
                $group,
                $gradeSubject
            ),
        ]);
    }

    /**
     * Legacy topic endpoint.
     */
    public function topics(
        Request $request,
        Group $group,
        GradeSubject $gradeSubject,
        $unit
    ) {
        $unit = Unit::findOrFail($unit);

        return response()->json([
            'data' => $this->context->topics(
                $request->user(),
                $group,
                $gradeSubject,
                $unit
            ),
        ]);
    }

    /**
     * Legacy objectives endpoint.
     */
    public function objectives(
        Request $request,
        Group $group,
        GradeSubject $gradeSubject,
        $unit,
        $topic
    ) {
        $unit = Unit::findOrFail($unit);
        $topic = Topic::findOrFail($topic);

        return response()->json([
            'data' => $this->context->objectives(
                $request->user(),
                $group,
                $gradeSubject,
                $unit,
                $topic
            ),
        ]);
    }

    /**
     * Create Tutor session.
     *
     * Student must provide:
     * - group_id
     * - learning_period_id
     * - grade_subject_id
     * - topic_id
     *
     * Student does NOT provide learning_objective_id.
     */
    public function createSession(
        Request $request
    ) {
        $data = $request->validate([
            'group_id' => [
                'required',
                'integer',
                'exists:groups,id',
            ],

            'learning_period_id' => [
                'required',
                'integer',
                'exists:learning_periods,id',
            ],

            'grade_subject_id' => [
                'required',
                'integer',
                'exists:grade_subjects,id',
            ],

            'topic_id' => [
                'required',
                'integer',
                'exists:topics,id',
            ],
        ]);

        $session = $this->sessionsService->create(
            $request->user(),
            $data
        );

        return response()->json([
            'message' =>
            'Tutor session started successfully.',

            'data' => $session,
        ], 201);
    }

    /**
     * Send student message.
     */
    public function message(
        Request $request,
        TutorSession $tutorSession
    ) {
        abort_unless(
            (int) $tutorSession->student_id ===
                (int) $request->user()->id,
            403
        );

        abort_if(
            $tutorSession->status !== 'active',
            422,
            'This tutor session is no longer active.'
        );

        $data = $request->validate([
            'message' => [
                'required',
                'string',
                'max:4000',
            ],
        ]);

        $answer = $this->ai->answer(
            $tutorSession,
            $data['message']
        );

        $tutorSession->messages()->createMany([
            [
                'role' => 'user',
                'message_type' => 'text',
                'content' => $data['message'],
            ],
            [
                'role' => 'assistant',
                'message_type' => 'text',
                'content' => $answer,
            ],
        ]);

        $tutorSession->update([
            'last_activity_at' => now(),
        ]);

        return response()->json([
            'data' => [
                'session_id' =>
                $tutorSession->id,

                'answer' => $answer,
            ],
        ]);
    }

    /**
     * Student's Tutor sessions.
     */
    public function sessions(Request $request)
    {
        $sessions = TutorSession::query()
            ->where(
                'student_id',
                $request->user()->id
            )
            ->with([
                'group:id,group_name,class_code',

                'learningPeriod:id,title,start_date,end_date,status',

                'gradeSubject.subject:id,name',

                'unit:id,name',

                'topic:id,topic_name',
            ])
            ->withCount('messages')
            ->latest('last_activity_at')
            ->paginate(15);

        return response()->json([
            'data' => $sessions,
        ]);
    }

    /**
     * Show one Tutor session.
     */
    public function showSession(
        Request $request,
        TutorSession $tutorSession
    ) {
        abort_unless(
            (int) $tutorSession->student_id ===
                (int) $request->user()->id,
            403
        );

        return response()->json([
            'data' => $tutorSession->load([
                'group:id,group_name,class_code',

                'learningPeriod:id,group_id,grade_subject_id,title,description,start_date,end_date,status',

                'gradeSubject.subject:id,name',

                'gradeSubject.gradeLevel:id,grade_name',

                'unit:id,name',

                'topic:id,topic_name',

                'objectives.learningObjective:id,topic_id,code,objective,description,order,status',

                'messages:id,tutor_session_id,role,message_type,content,created_at',
            ]),
        ]);
    }

    /**
     * End Tutor session.
     */
    public function endSession(
        Request $request,
        TutorSession $tutorSession
    ) {
        $data = $request->validate([
            'status' => [
                'nullable',
                'in:completed,abandoned',
            ],
        ]);

        return response()->json([
            'data' => $this->sessionsService->finish(
                $request->user(),
                $tutorSession,
                $data['status'] ?? 'completed'
            ),
        ]);
    }

    /**
     * Legacy Tutor endpoint.
     *
     * Keep temporarily for old clients.
     */
    public function ask(
        Request $request,
        GroqAIService $groqAI
    ) {
        $data = $request->validate([
            'course_material_id' => [
                'required',
                'integer',
                'exists:course_materials,id',
            ],

            'session_id' => [
                'nullable',
                'integer',
                'exists:tutor_sessions,id',
            ],

            'message' => [
                'required',
                'string',
                'max:4000',
            ],

            'conversation' => [
                'nullable',
                'array',
                'max:20',
            ],

            'conversation.*.role' => [
                'required',
                'in:user,assistant',
            ],

            'conversation.*.content' => [
                'required',
                'string',
                'max:4000',
            ],
        ]);

        $material = CourseMaterial::query()
            ->whereKey(
                $data['course_material_id']
            )
            ->where('status', 'approved')
            ->where(
                'extraction_status',
                'ready'
            )
            ->whereNotNull('extracted_text')
            ->firstOrFail();

        $session = null;

        if (!empty($data['session_id'])) {
            $session = TutorSession::whereKey(
                $data['session_id']
            )
                ->where(
                    'student_id',
                    $request->user()->id
                )
                ->firstOrFail();
        }

        if (!$session) {
            $session = TutorSession::create([
                'student_id' =>
                $request->user()->id,

                'course_material_id' =>
                $material->id,

                'title' =>
                $material->title,

                'status' => 'active',

                'started_at' => now(),

                'last_activity_at' => now(),
            ]);
        }

        $messages = $session
            ->messages()
            ->latest()
            ->limit(20)
            ->get()
            ->reverse()
            ->values()
            ->map(
                fn(
                    TutorMessage $message
                ) => [
                    'role' => $message->role,
                    'content' => $message->content,
                ]
            )
            ->all();

        if (empty($messages)) {
            $messages = collect(
                $data['conversation'] ?? []
            )
                ->map(
                    fn(array $message) => [
                        'role' => $message['role'],
                        'content' =>
                        $message['content'],
                    ]
                )
                ->all();
        }

        $messages[] = [
            'role' => 'user',
            'content' => $data['message'],
        ];

        $answer = $groqAI->askTutor(
            $material->title,
            $material->extracted_text,
            $messages
        );

        $session->messages()->createMany([
            [
                'role' => 'user',
                'message_type' => 'text',
                'content' => $data['message'],
            ],
            [
                'role' => 'assistant',
                'message_type' => 'text',
                'content' => $answer,
            ],
        ]);

        $session->update([
            'last_activity_at' => now(),
        ]);

        return response()->json([
            'data' => [
                'session_id' =>
                $session->id,

                'answer' => $answer,

                'course_material' => [
                    'id' => $material->id,
                    'title' => $material->title,
                    'subject_id' =>
                    $material->subject_id,
                    'topic_id' =>
                    $material->topic_id,
                ],
            ],
        ]);
    }
}
