<?php

namespace App\Http\Controllers;

// use App\Models\Group;
use App\Models\Topic;
use App\Models\Question;
use App\Models\Assessment;
use Illuminate\Http\Request;
use App\Models\QuestionUsage;
use App\Models\AssessmentSection;
use App\Models\StudentAssessment;
use App\Models\LearnerFormativeAttempt;
use App\Models\AssessmentQuestion;
use Illuminate\Support\Facades\DB;
use App\Services\AssessmentAssigner;
use App\Services\LearningPeriodFormativeService;
use Illuminate\Support\Facades\Auth;
use App\Models\StudentQuestionHistory;

class AssessmentController extends Controller
{
    public function listCreatedAssessments()
    {
        $user = Auth::user();

        $assessments = Assessment::where('creator_id', $user->id)
            ->with([
                'questions.question',
                'topics.gradeSubject.subject',
                'topics.gradeSubject.gradeLevel',
                'groups:id,group_name,class_code',
            ])
            ->withCount([
                'studentAssessments as assigned_students_count',
                'studentAssessments as started_attempts_count' => function ($query) {
                    // student_assessments does not have a started_at column.
                    // Assigned (pending) records are not started attempts.
                    $query->whereIn('status', [
                        'in_progress', 'completed', 'graded', 'under_review',
                    ]);
                },
            ])
            ->latest()
            ->get();

        $createdAssessments = $assessments->map(function ($assessment) {

            $assessment->question_count = $assessment->questions
                ->filter(fn($assessmentQuestion) => $assessmentQuestion->question)
                ->count();

            $assessment->total_marks = $assessment->questions
                ->sum(function ($assessmentQuestion) {
                    return (float) ($assessmentQuestion->question?->marks ?? 0);
                });
            $assessment->total_score = $assessment->total_marks;

            $topicIds = $assessment->questions
                ->pluck('question.topic_id')
                ->unique()
                ->filter();

            $topics = Topic::whereIn('id', $topicIds)->get();

            $assessment->topics = $topics;

            $subjectGradeLevels = $assessment->topics
                ->map(function ($topic) {

                    $gradeSubject = $topic->gradeSubject;

                    $subjectName = $gradeSubject?->subject?->name;
                    $gradeLevelName = $gradeSubject?->gradeLevel?->grade_name;

                    if ($subjectName && $gradeLevelName) {
                        return [
                            'subject' => $subjectName,
                            'grade_level' => $gradeLevelName,
                        ];
                    }

                    return null;
                })
                ->filter()
                ->unique()
                ->values();

            $assessment->primary_subject =
                $subjectGradeLevels->first()['subject'] ?? null;

            $assessment->primary_grade_level =
                $subjectGradeLevels->first()['grade_level'] ?? null;

            $assessment->subject_grade_levels = $subjectGradeLevels;

            return $assessment;
        });

        return response()->json([
            'created_assessments' => $createdAssessments
        ]);
    }
    // List all practice assessments for the authenticated student
    public function listPracticeAssessments(Request $request)
    {
        $student = Auth::user();
        if (!$student || $student->role !== 'student') {
            return response()->json(['message' => 'Only students can view their practice assessments.'], 403);
        }
        $practiceAssessments = Assessment::where('type', 'practice')
            ->whereHas('studentAssessments', function ($q) use ($student) {
                $q->where('student_id', $student->id);
            })
            ->with(['questions.question', 'subject', 'studentAssessments' => function ($q) use ($student) {
                $q->where('student_id', $student->id);
            }])
            ->latest()
            ->get();

        $practiceAssessments = $practiceAssessments->map(function ($assessment) {
            $topicIds = $assessment->questions->pluck('question.topic_id')->unique()->filter();
            $topics = Topic::whereIn('id', $topicIds)->get();
            $assessment->topics = $topics;

            // Compute subject/grade-level pairs from topics (subjects derived from topics)
            $subjectGradeLevels = $assessment->topics->map(function ($topic) {
                $gradeSubject = $topic->gradeSubject;
                $subjectName = $gradeSubject?->subject?->name;
                $gradeLevelName = $gradeSubject?->gradeLevel?->grade_name;

                if ($subjectName && $gradeLevelName) {
                    return [
                        'subject' => $subjectName,
                        'grade_level' => $gradeLevelName,
                    ];
                }
                return null;
            })->filter()->unique()->values();

            // Optional: primary subject/grade for quick display
            $assessment->primary_subject = $subjectGradeLevels->first()['subject'] ?? null;
            $assessment->primary_grade_level = $subjectGradeLevels->first()['grade_level'] ?? null;

            // All pairs if you need them on the frontend
            $assessment->subject_grade_levels = $subjectGradeLevels;

            // Attach student_assessment details for this student
            $studentAssessment = $assessment->studentAssessments->first();
            $assessment->student_assessment = $studentAssessment;
            // Attach student results if available
            if ($studentAssessment) {
                $assessment->student_results = [
                    'score' => $studentAssessment->score,
                    'max_score' => $studentAssessment->max_score,
                    'status' => $studentAssessment->status,
                    'completed_at' => $studentAssessment->completed_at,
                    'answers' => $studentAssessment->studentAnswers ?? []
                ];
            } else {
                $assessment->student_results = null;
            }
            unset($assessment->studentAssessments);
            return $assessment;
        });

        // Assigned assessments (non-practice types) for the student
        $assignedAssessments = Assessment::where('type', '!=', 'practice')
            ->whereHas('studentAssessments', function ($q) use ($student) {
                $q->where('student_id', $student->id);
            })
            ->with(['questions.question', 'subject', 'studentAssessments' => function ($q) use ($student) {
                $q->where('student_id', $student->id);
            }])
            ->latest()
            ->get();

        $assignedAssessments = $assignedAssessments->map(function ($assessment) {
            $topicIds = $assessment->questions->pluck('question.topic_id')->unique()->filter();
            $topics = Topic::whereIn('id', $topicIds)->get();
            $assessment->topics = $topics;

            // Compute subject/grade-level pairs from topics (subjects derived from topics)
            $subjectGradeLevels = $assessment->topics->map(function ($topic) {
                $gradeSubject = $topic->gradeSubject;
                $subjectName = $gradeSubject?->subject?->name;
                $gradeLevelName = $gradeSubject?->gradeLevel?->grade_name;

                if ($subjectName && $gradeLevelName) {
                    return [
                        'subject' => $subjectName,
                        'grade_level' => $gradeLevelName,
                    ];
                }
                return null;
            })->filter()->unique()->values();

            // Optional: primary subject/grade for quick display
            $assessment->primary_subject = $subjectGradeLevels->first()['subject'] ?? null;
            $assessment->primary_grade_level = $subjectGradeLevels->first()['grade_level'] ?? null;

            // All pairs if you need them on the frontend
            $assessment->subject_grade_levels = $subjectGradeLevels;

            // Attach student_assessment details for this student
            $studentAssessment = $assessment->studentAssessments->first();
            $assessment->student_assessment = $studentAssessment;
            // Attach student results if available
            if ($studentAssessment) {
                $assessment->student_results = [
                    'score' => $studentAssessment->score,
                    'max_score' => $studentAssessment->max_score,
                    'status' => $studentAssessment->status,
                    'completed_at' => $studentAssessment->completed_at,
                    'answers' => $studentAssessment->studentAnswers ?? []
                ];
            } else {
                $assessment->student_results = null;
            }
            unset($assessment->studentAssessments);
            return $assessment;
        });

        return response()->json([
            'practice_assessments' => $practiceAssessments,
            'assigned_assessments' => $assignedAssessments
        ]);
    }

    public function updateTitle($id, Request $request)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
        ]);

        $assessment = Assessment::find($id);
        if (!$assessment) {
            return response()->json(['message' => 'Assessment not found'], 404);
        }

        $assessment->title = $data['title'];
        $assessment->save();

        return response()->json(['assessment' => $assessment], 200);
    }
    // Get assessment details (questions) for answering
    public function questionsForPractice(
        $id,
        AssessmentAssigner $assigner,
        LearningPeriodFormativeService $formativeService
    )
    {
        $assessment = Assessment::findOrFail($id);

        // Personalized formative questions belong to the student's attempt,
        // not to the shared assessment_questions pivot. Never serve the empty
        // shared container as a normal assessment (or mix learners' questions).
        if ($assessment->purpose === 'learner_personalized_formative') {
            $student = Auth::user();
            abort_unless($student && $student->role === 'student', 403);

            $attempt = LearnerFormativeAttempt::query()
                ->where('student_id', $student->id)
                ->where('assessment_id', $assessment->id)
                ->latest('id')
                ->first();

            if (!$attempt) {
                return response()->json([
                    'message' => 'Your personalized questions have not been prepared yet. Open your AI Tutor learning period to prepare your formative assessment.',
                ], 409);
            }

            if ($attempt->status === 'completed') {
                return response()->json([
                    'personalized_formative_attempt_id' => $attempt->id,
                    'student_assessment_id' => $attempt->student_assessment_id,
                    'completed' => true,
                ]);
            }

            if (!in_array($attempt->status, ['ready', 'in_progress'], true)) {
                return response()->json([
                    'message' => $attempt->status === 'failed'
                        ? ($attempt->error_message ?: 'Question preparation failed. Please retry from your AI Tutor learning period.')
                        : 'Your personalized questions are still being prepared. Please return to your AI Tutor learning period.',
                    'preparation_status' => $attempt->status,
                ], 409);
            }

            return response()->json([
                'personalized_formative_attempt_id' => $attempt->id,
            ]);
        }

        $formativeService->assertStudentReadyForAssessment(
            Auth::user(),
            $assessment
        );

        // Create the immutable presentation snapshot before returning any
        // questions. This prevents the initial GET from exposing an unshuffled
        // version before the normal POST /start call.
        $student = Auth::user();
        if (($assessment->shuffle_questions || $assessment->shuffle_options)
            && $student && $student->role === 'student') {
            $existing = StudentAssessment::where('student_id', $student->id)
                ->where('assessment_id', $assessment->id)->first();
            $isOwnPractice = $assessment->type === 'practice'
                && (int) $assessment->creator_id === (int) $student->id;
            $isGroupAssignment = $assessment->groups()
                ->whereIn('groups.id', $student->groups()->pluck('groups.id'))->exists();
            abort_unless($existing || $isOwnPractice || $isGroupAssignment,
                403, 'This assessment is not assigned to you.');

            abort_if($existing && in_array($existing->status,
                ['completed', 'graded', 'under_review'], true),
                409, 'Assessment already submitted.');

            $studentAssessment = StudentAssessment::firstOrCreate(
                ['student_id' => $student->id, 'assessment_id' => $assessment->id],
                ['assigned_by' => $assessment->creator_id, 'assigned_at' => now(),
                 'status' => 'in_progress']
            );
            if ($studentAssessment->status !== 'in_progress') {
                $studentAssessment->update(['status' => 'in_progress']);
            }
            app(\App\Services\AssessmentShuffleService::class)
                ->ensureSnapshot($assessment, $studentAssessment);
        }

        $data = $assigner->questionsForPractice($id);
        return response()->json($data);
    }

    public function show($id)
    {
        // Eager load each question and its sub-questions
        $assessment = Assessment::with([
            'questions.question.subQuestions',
            'topics.gradeSubject.subject',
            'topics.gradeSubject.gradeLevel',
            'creator.school'
        ])->findOrFail($id);

        // Get all subject/grade level pairs for the assessment's topics
        $subjectGradeLevels = $assessment->topics->map(function ($topic) {
            $gradeSubject = $topic->gradeSubject;
            $subjectName = $gradeSubject?->subject?->name;
            $gradeLevelName = $gradeSubject?->gradeLevel?->grade_name;
            if ($subjectName && $gradeLevelName) {
                return [
                    'subject' => $subjectName,
                    'grade_level' => $gradeLevelName
                ];
            }
            return null;
        })->filter()->unique()->values();

        $student = Auth::user();
        $studentAssessment = StudentAssessment::where('assessment_id', $assessment->id)
            ->where('student_id', $student->id)
            ->first();
        $assessment->student_assessment_id = $studentAssessment ? $studentAssessment->id : null;

        // Get topic object from the first question's topic (if available)
        $topic = null;
        if ($assessment->questions && $assessment->questions->count() > 0) {
            $firstQuestion = $assessment->questions->first()->question;
            if ($firstQuestion && $firstQuestion->topic) {
                $topic = $firstQuestion->topic;
            }
        }

        // Use the first subject/grade level as primary, or fallback
        $primarySubject = $subjectGradeLevels->first()['subject'] ?? 'General';
        $primaryGradeLevel = $subjectGradeLevels->first()['grade_level'] ?? null;

        // Get logo_path from creator's school if available
        $logoPath = $assessment->creator && $assessment->creator->school ? $assessment->creator->school->logo_path : null;

        // Normalize questions: return parent questions with nested sub_questions
        $normalizedQuestions = [];

        // Ensure assessment questions are processed in stable order (AssessmentQuestion.order)
        $assessmentQuestions = $assessment->questions->sortBy(function ($aq) {
            return $aq->order ?? 0;
        })->values();

        foreach ($assessmentQuestions as $aq) {
            $q = $aq->question;
            if (! $q) {
                continue;
            }
            // Skip child questions here; they will be nested under their parent
            if ($q->parent_question_id) {
                continue;
            }

            // Build base item and ensure option JSON is decoded
            $item = $q->toArray();
            $item['assessment_order'] = $aq->order ?? null;

            // Normalize options (decode if string) and resolve option images
            if (isset($item['options']) && is_string($item['options'])) {
                $decoded = json_decode($item['options'], true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $item['options'] = $decoded;
                }
            }

            if (is_array($item['options'] ?? null)) {
                $item['options'] = array_map(function ($opt) {
                    if (is_array($opt)) {
                        if (!empty($opt['image'])) {
                            $opt['image_url'] = asset('storage/' . $opt['image']);
                        }
                        if (isset($opt['text']) && is_string($opt['text'])) {
                            $opt['text'] = $opt['text'];
                        }
                        return $opt;
                    }
                    return $opt;
                }, $item['options']);
            }

            // Ensure question and correct answer image URLs are set
            $item['question_image_url'] = $q->question_image ? asset('storage/' . $q->question_image) : null;
            $item['correct_answer_image_url'] = $q->correct_answer_image ? asset('storage/' . $q->correct_answer_image) : null;

            // Include any sub-questions (stable ordered by id)
            $subQuestions = $q->subQuestions->sortBy('id')->values();
            $item['sub_questions'] = $subQuestions->map(function ($sq) use ($aq) {
                $sub = $sq->toArray();
                // decode options for sub-question
                if (isset($sub['options']) && is_string($sub['options'])) {
                    $decoded = json_decode($sub['options'], true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $sub['options'] = $decoded;
                    }
                }
                if (is_array($sub['options'] ?? null)) {
                    $sub['options'] = array_map(function ($opt) {
                        if (is_array($opt) && !empty($opt['image'])) {
                            $opt['image_url'] = asset('storage/' . $opt['image']);
                        }
                        return $opt;
                    }, $sub['options']);
                }
                $sub['question_image_url'] = $sq->question_image ? asset('storage/' . $sq->question_image) : null;
                $sub['correct_answer_image_url'] = $sq->correct_answer_image ? asset('storage/' . $sq->correct_answer_image) : null;
                // reference parent's assessment order
                $sub['assessment_order'] = $aq->order ?? null;
                return $sub;
            })->values();

            $normalizedQuestions[] = $item;
        }

        // Management controls need authoritative counts, not the frontend list's cached values.
        if ((int) $assessment->creator_id === (int) Auth::id()) {
            $assessment->assigned_students_count = $assessment->studentAssessments()->count();
            $assessment->started_attempts_count = $assessment->studentAssessments()
                ->whereIn('status', ['in_progress', 'completed', 'graded', 'under_review'])
                ->count();
        }

        // Replace the questions relation in the returned assessment with normalized structure
        $assessment->setRelation('questions', collect($normalizedQuestions));

        return response()->json([
            'assessment' => $assessment,
            'topic' => $topic,
            'subject' => $primarySubject,
            'grade_level' => $primaryGradeLevel,
            'subject_grade_levels' => $subjectGradeLevels,
            'logo_path' => $logoPath
        ]);
    }

    // Create a practice assessment for a student with all questions from a selected topic
    public function createPracticeForTopic(Request $request)
    {
        $validated = $request->validate([
            'topic_id' => 'required|exists:topics,id',
            'mode' => 'required|in:all,custom,unpracticed',
            'limit' => 'nullable|integer|min:1'
        ]);

        $student = Auth::user();
        if (!$student || $student->role !== 'student') {
            return response()->json(['message' => 'Only students can start a practice session.'], 403);
        }

        $topic = Topic::find($validated['topic_id']);
        if (!$topic) {
            return response()->json(['message' => 'Topic not found.', 404]);
        }

        // Total questions available for the topic (leaf questions only: no sub-questions)
        $totalQuestions = Question::where('topic_id', $topic->id)
            ->whereDoesntHave('subQuestions')
            ->count();

        //Business rule: if <=10, force mode = all

        if ($totalQuestions <= 10) {
            $validated['mode'] = 'all';
            $validated['limit'] = null;
        }
        // Build base query (leaf questions only)
        $questionQuery = Question::where('topic_id', $topic->id)
            ->whereDoesntHave('subQuestions');
        if ($validated['mode'] === 'unpracticed') {
            // StudentQuestionHistory doesn't store topic_id; find practiced question ids
            // for this student, then filter those that belong to the requested topic.
            $practicedIds = StudentQuestionHistory::where('student_id', $student->id)
                ->pluck('question_id');

            if ($practicedIds->isNotEmpty()) {
                $topicPracticed = Question::where('topic_id', $topic->id)
                    ->whereIn('id', $practicedIds)
                    ->pluck('id');

                if ($topicPracticed->isNotEmpty()) {
                    $questionQuery->whereNotIn('id', $topicPracticed);
                }
            }
        }

        // Select questions
        $questions = match ($validated['mode']) {
            'all' => $questionQuery->get(),
            default => $questionQuery->inRandomOrder()->take($validated['limit'])->get(),
        };

        if ($questions->isEmpty()) {
            return response()->json(['message' => 'No questions found for this topic.'], 404);
        }

        // Create the title suffix
        $titleSuffix = match ($validated['mode']) {
            'all' => 'Practice All Questions',
            'custom' => "{$validated['limit']} Questions",
            'unpracticed' => "{$validated['limit']} Unpracticed Questions",
        };

        // Create the practice assessment
        $practiceAssessment = Assessment::create([
            'type' => 'practice',
            'title' => "Practice: {$titleSuffix}",
            'creator_id' => $student->id,
            'question_count' => $questions->count(),
            'due_date' => now()->addDay(), // Use due_date instead of start_time/end_time
            'is_timed' => false,
            'time_limit' => null,
        ]);
        // Attach topic via pivot
        $practiceAssessment->topics()->attach($topic->id);

        // Associate questions with the assessment
        foreach ($questions as $order => $question) {
            AssessmentQuestion::create([
                'assessment_id' => $practiceAssessment->id,
                'question_id' => $question->id,
                'order' => $order + 1,
            ]);
        }

        // Optionally, assign the assessment to the student
        $studentAssessment = StudentAssessment::create([
            'student_id' => $student->id,
            'assessment_id' => $practiceAssessment->id,
            'status' => 'in_progress',
        ]);

        return response()->json([
            'message' => 'Practice assessment created',
            'assessment' => $practiceAssessment,
            'student_assessment' => $studentAssessment,
        ], 201);
    }

    // Create or initiate an assessment (quiz or practice)
    public function createAssessment(Request $request)
    {
        $validated = $request->validate([
            'type' => 'required|in:quiz,homework,exam',
            'title' => 'required|string|max:255',
            'topic_id' => 'required|exists:topics,id',
            'delivery_mode' => 'required|in:online,offline',
            'due_date' => 'nullable|date|after_or_equal:start_time',
            'is_timed' => 'boolean',
            'time_limit' => 'nullable|integer|min:1',
            'use_default_sections' => 'sometimes|boolean',
            'shuffle_questions' => 'sometimes|boolean',
            'shuffle_options' => 'sometimes|boolean',

        ]);
        // Adjust field based on delivery mode
        if ($validated['delivery_mode'] === 'online') {
            $request->validate([
                'due_date' => 'required|date|after_or_equal:today',
                'is_timed' => 'required|boolean',
                'time_limit' => 'nullable|integer|min:1',
            ]);
        } else {
            // Set fields to null/false for offline assessments
            $validated['due_date'] = null;
            $validated['is_timed'] = false;
            $validated['time_limit'] = null;
        }

        // Create the assessment
        $assessment = Assessment::create([
            'type' => $validated['type'],
            'title' => $validated['title'],
            'creator_id' => Auth::id(), // Use authenticated user ID
            'question_count' => 0, // Will be updated later
            'due_date' => $validated['due_date'] ?? now(),
            'is_timed' => $validated['is_timed'] ?? false,
            'time_limit' => $validated['time_limit'] ?? null,
            'delivery_mode' => $validated['delivery_mode'],
            'shuffle_questions' => (bool) ($validated['shuffle_questions'] ?? false),
            'shuffle_options' => (bool) ($validated['shuffle_options'] ?? false),
        ]);
        // Attach the provided topic via pivot
        $assessment->topics()->attach($validated['topic_id']);

        // Optionally create default sections for "standard" assessments
        if (!empty($validated['use_default_sections'])) {
            $defaultSections = AssessmentSection::orderBy('ordering')->get();

            foreach ($defaultSections as $default) {
                AssessmentSection::create([
                    'assessment_id' => $assessment->id,
                    'title' => $default->title,
                    'instruction' => $default->default_instruction,
                    'ordering' => $default->ordering,
                ]);
            }
        }
        return response()->json([
            'message' => 'Assessment created successfully',
            'assessment' => $assessment
        ], 201);
    }

    /**
     * Update assessment instructions separately during the build phase.
     */
    public function updateInstructions(Request $request, $id)
    {
        $data = $request->validate([
            'instructions' => 'nullable|string',
        ]);

        $assessment = Assessment::findOrFail($id);



        // Only the creator can modify instructions
        if ($assessment->creator_id !== Auth::id()) {
            return response()->json([
                'message' => 'You are not authorized to update instructions for this assessment.',
            ], 403);
        }

        $assessment->instructions = $data['instructions'] ?? null;
        $assessment->save();

        return response()->json([
            'message' => 'Instructions updated successfully',
            'assessment' => $assessment,
        ]);
    }

    /**
     * Protect delivered assessment papers and learners' existing answers.
     * Only the creator can edit, and only before an attempt has started.
     */
    private function ensureQuestionEditingAllowed(Assessment $assessment): void
    {
        abort_unless((int) $assessment->creator_id === (int) Auth::id(), 403,
            'Only the assessment creator can edit questions.');
        abort_if($assessment->is_system_generated || $assessment->status === 'archived', 422,
            'System-generated or archived assessments cannot be edited.');
        abort_if($assessment->studentAssessments()->whereIn('status',
            ['in_progress', 'completed', 'graded', 'under_review'])->exists(), 422,
            'Students have already started this assessment. Questions cannot be changed.');
    }

    // Add questions to an assessment
    public function addQuestions(Request $request)
    {
        $validated = $request->validate([
            'assessment_id' => 'required|exists:assessments,id',
            'question_ids' => 'required|array|min:1',
            'question_ids.*' => 'exists:questions,id',
        ]);

        $assessment = Assessment::findOrFail($validated['assessment_id']);
        $this->ensureQuestionEditingAllowed($assessment);
        $now = now();
        $userId = auth()->id();

        // Get all current assessment_question rows for this assessment
        $existing = $assessment->questions()->pluck('id', 'question_id')->toArray(); // [question_id => assessment_question_id]
        $warnings = []; // <--- store warnings to return to frontend

        foreach (array_values($validated['question_ids']) as $order => $qid) {
            // Check usage by same user (limit = 3)
            $usageCount = QuestionUsage::where('question_id', $qid)
                ->whereHas('assessment', function ($q) use ($userId) {
                    $q->where('creator_id', $userId);
                })->count();
            if ($usageCount >= 10) {
                $warnings[] = "Question ID {$qid} has been used in 10 or more assessments created by you.";
            }
            // -------------------------------------------------------
            if (isset($existing[$qid])) {
                // Update order for existing question
                AssessmentQuestion::where('id', $existing[$qid])
                    ->update(['order' => $order + 1, 'updated_at' => $now]);
            } else {
                // Insert new question
                AssessmentQuestion::create([
                    'assessment_id' => $assessment->id,
                    'question_id' => $qid,
                    'order' => $order + 1,
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);

                // Log usage when a new question is added

                QuestionUsage::create([
                    'question_id' => $qid,
                    'assessment_id' => $assessment->id,
                    'used_at' => $now,
                ]);
            }
        }

        // Remove any questions not in the new list
        $toRemove = array_diff(array_keys($existing), $validated['question_ids']);
        if (!empty($toRemove)) {
            AssessmentQuestion::where('assessment_id', $assessment->id)
                ->whereIn('question_id', $toRemove)
                ->delete();
        }

        // Update question count
        $assessment->question_count = $assessment->questions()->count();
        $assessment->save();

        return response()->json([
            'message' => 'Questions added/updated successfully',
            'warnings' => $warnings,
            'assessment' => $assessment->load('questions.question')
        ], 200);
    }
    public function getAssessmentQuestions($id)
    {
        $assessment = Assessment::with('questions')->findOrFail($id);
        return response()->json(['questions' => $assessment->questions]);
    }

    public function removeQuestion($assessmentId, $questionId)
    {
        $assessment = Assessment::findOrFail($assessmentId);
        $this->ensureQuestionEditingAllowed($assessment);
        AssessmentQuestion::where('assessment_id', $assessmentId)
            ->where('question_id', $questionId)
            ->delete();

        // Update count
        $assessment = Assessment::findOrFail($assessmentId);
        $assessment->question_count = $assessment->questions()->count();
        $assessment->save();

        return response()->json(['message' => 'Question removed']);
    }
    // Assign an assessment (quiz or practice) to a student or a group of students
    public function assign(Request $request, AssessmentAssigner $assigner)
    {
        $request->validate([
            'assessment_id' => 'required|exists:assessments,id',
            'student_id' => 'nullable|exists:users,id',
            'grade_level_id' => 'nullable|exists:grade_levels,id',
        ]);

        $assessmentId = $request->assessment_id;
        $assignedCount = 0;

        if ($request->filled('student_id')) {
            $success = $assigner->assignToStudent($request->student_id, $assessmentId);

            return response()->json([
                'message' => $success
                    ? 'Assessment assigned to student'
                    : 'Student already has this assessment',
                'assigned_count' => $success ? 1 : 0,
            ]);
        }

        if ($request->filled('grade_level_id')) {
            $assignedCount = $assigner->assignToGrade($request->grade_level_id, $assessmentId);

            return response()->json([
                'message' => "Assessment assigned to {$assignedCount} students",
                'assigned_count' => $assignedCount,
            ]);
        }

        return response()->json([
            'error' => 'You must provide either student_id or grade_level_id',
        ], 422);
    }

    public function assignGroup(Request $request, $assessmentId)
    {
        $validated = $request->validate([
            'group_id' => 'required|exists:groups,id',
        ]);

        $assessment = Assessment::findOrFail($assessmentId);
        abort_unless((int) $assessment->creator_id === (int) Auth::id(), 403,
            'Only the assessment creator can assign this assessment.');
        abort_unless($assessment->status === 'published', 422,
            'Only published assessments can be assigned.');
        $group = \App\Models\Group::findOrFail($validated['group_id']);
        abort_unless((int) $group->created_by === (int) Auth::id(), 403,
            'You can only assign an assessment to a class you manage.');

        // Attach group to the assessment
        // Using syncWithoutDetaching in case you want to keep other groups attached
        $assessment->groups()->syncWithoutDetaching([$validated['group_id']]);



        return response()->json(['message' => 'Assessment assigned successfully']);
    }


    // Start a practice assessment for the authenticated student
    public function startPractice(Request $request)
    {
        $request->validate([
            'assessment_id' => 'required|exists:assessments,id',
        ]);

        $assessment = Assessment::where('id', $request->assessment_id)->where('type', 'practice')->firstOrFail();
        $student = Auth::user();
        $studentAssessment = StudentAssessment::create([
            'student_id' => $student->id,
            'assessment_id' => $assessment->id,
            'status' => 'in_progress',
        ]);

        return response()->json(['message' => 'Practice started', 'student_assessment' => $studentAssessment]);
    }

    public function showResults($studentAssessmentId)
    {
        $studentAssessment = StudentAssessment::with(['assessment', 'studentAnswers.question'])
            ->findOrFail($studentAssessmentId);

        // Ensure the authenticated user is authorized to view these results
        if ($studentAssessment->student_id !== Auth::id()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        // Completed assessments remain reviewable after a teacher re-marks
        // them and the status moves to `graded`.
        if (!in_array($studentAssessment->status, ['completed', 'graded', 'under_review'], true)) {
            return response()->json(['message' => 'Assessment not completed yet'], 400);
        }

        $assessment = $studentAssessment->assessment;
        $studentAnswers = $studentAssessment->studentAnswers;

        // Personalized formative attempts persist the exact option order shown
        // to the learner. Reuse that order on the results screen so review
        // matches the assessment the learner actually saw.
        $learnerAttempt = LearnerFormativeAttempt::query()
            ->with('questions')
            ->where('student_assessment_id', $studentAssessment->id)
            ->first();

        $attemptQuestionMap = $learnerAttempt
            ? $learnerAttempt->questions->keyBy('question_id')
            : collect();

        $normalizeText = fn ($value) => mb_strtolower(trim((string) ($value ?? '')));

        $resolveMcqAnswers = function ($correctRaw, array $options) use ($normalizeText) {
            if (is_string($correctRaw)) {
                $trimmed = trim($correctRaw);
                if (
                    (str_starts_with($trimmed, '[') && str_ends_with($trimmed, ']')) ||
                    (str_starts_with($trimmed, '{') && str_ends_with($trimmed, '}'))
                ) {
                    $decoded = json_decode($trimmed, true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        $correctRaw = $decoded;
                    }
                }
            }

            $values = is_array($correctRaw) ? $correctRaw : [$correctRaw];

            $optionTexts = array_map(function ($option) {
                if (is_array($option)) {
                    $text = trim((string) ($option['text'] ?? $option['label'] ?? $option['value'] ?? ''));
                    if ($text !== '') return $text;
                    $image = (string) ($option['image'] ?? $option['option_image'] ?? $option['image_url'] ?? '');
                    if (str_contains($image, '/storage/')) $image = explode('/storage/', $image, 2)[1];
                    $image = ltrim(preg_replace('/[?#].*$/', '', $image), '/');
                    if (str_starts_with($image, 'storage/')) $image = substr($image, 8);
                    return $image !== '' ? 'image:' . $image : '';
                }
                return (string) $option;
            }, $options);

            $resolved = [];

            foreach ($values as $value) {
                if ($value === null || $value === '') {
                    continue;
                }

                $raw = trim((string) $value);

                // Exact option text is the most stable representation.
                foreach ($optionTexts as $text) {
                    if ($normalizeText($text) === $normalizeText($raw)) {
                        $resolved[] = $text;
                        continue 2;
                    }
                }

                // Legacy A/B/C/D answer keys.
                if (preg_match('/^[A-Za-z]$/', $raw)) {
                    $index = ord(strtoupper($raw)) - 65;
                    if (isset($optionTexts[$index])) {
                        $resolved[] = $optionTexts[$index];
                        continue;
                    }
                }

                // Legacy zero-based numeric option indices. Only treat a number
                // as an index if it does not already match an option text.
                if (ctype_digit($raw)) {
                    $index = (int) $raw;
                    if (isset($optionTexts[$index])) {
                        $resolved[] = $optionTexts[$index];
                        continue;
                    }
                }

                $resolved[] = $raw;
            }

            return array_values(array_unique(array_filter($resolved, fn ($v) => trim((string) $v) !== '')));
        };

        // Convert completed_at and started_at to Carbon instances if they are strings
        $completedAt = $studentAssessment->completed_at;
        $startedAt = $studentAssessment->started_at;
        if ($completedAt && is_string($completedAt)) {
            $completedAt = \Carbon\Carbon::parse($completedAt);
        }
        if ($startedAt && is_string($startedAt)) {
            $startedAt = \Carbon\Carbon::parse($startedAt);
        }

        $excludedQuestionIds = app(\App\Services\AssessmentQuestionExclusionService::class)
            ->excludedIds((int) $assessment->id);
        $results = [
            'assessment_title' => $assessment->title,
            'assessment_type' => $assessment->type,
            'total_questions' => $assessment->question_count,
            'score' => $studentAssessment->status === 'under_review' ? null : $studentAssessment->score,
            'review_status' => $studentAssessment->status,
            'final_result_pending' => $studentAssessment->status === 'under_review',
            'max_score' => $studentAssessment->max_score,
            'percentage' => $studentAssessment->status !== 'under_review' && $studentAssessment->max_score > 0
                ? ($studentAssessment->score / $studentAssessment->max_score) * 100
                : null,
            'completed_at' => $studentAssessment->completed_at,
            'time_taken' => ($completedAt && $startedAt)
                ? $completedAt->diffInMinutes($startedAt)
                : null,
            'questions' => []
        ];

        foreach ($studentAnswers as $answer) {
            $question = $answer->question;

            // Decode options if it's a JSON string
            $options = $question->options;
            if (is_string($options)) {
                $options = json_decode($options, true);
            }

            // Apply the exact personalized option order used for this learner.
            $attemptQuestion = $attemptQuestionMap->get($question->id);
            if (
                is_array($options)
                && $attemptQuestion
                && is_array($attemptQuestion->option_order)
                && $question->question_type === 'mcq'
            ) {
                $reordered = [];
                foreach ($attemptQuestion->option_order as $originalIndex) {
                    if (array_key_exists($originalIndex, $options)) {
                        $reordered[] = $options[$originalIndex];
                    }
                }
                if (count($reordered) === count($options)) {
                    $options = $reordered;
                }
            }

            // Standard teacher-assigned/practice assessment option order is
            // stored on the student's attempt. Personalized formative uses its
            // own independent per-question order above.
            if (!$learnerAttempt && is_array($options) && $question->question_type === 'mcq') {
                $options = app(\App\Services\AssessmentShuffleService::class)
                    ->orderOptions($options, (int) $question->id, $studentAssessment);
            }

            // Add image URLs to options if they exist.
            if (is_array($options)) {
                $options = array_map(function ($opt) {
                    if (is_array($opt) && isset($opt['image']) && $opt['image']) {
                        $opt['image_url'] = asset('storage/' . $opt['image']);
                    }
                    return $opt;
                }, $options);
            }

            // Resolve legacy MCQ answer keys (A/B/C/D or indices) to semantic
            // option text so the frontend can highlight the correct choice
            // independently of option shuffling.
            $resolvedCorrectAnswer = $question->question_type === 'mcq'
                ? $resolveMcqAnswers($question->correct_answer, is_array($question->options) ? $question->options : (json_decode((string) $question->options, true) ?: []))
                : $question->correct_answer;

            $results['questions'][] = [
                'student_assessment_id' => $studentAssessment->id, // ✅ ADD THIS
                'question_id' => $question->id,
                'excluded' => in_array((int) $question->id, $excludedQuestionIds, true),
                'question_text' => $question->question,
                'stimulus' => $question->stimulus,
                'question_type' => $question->question_type,
                'options' => $options,
                // Support multiple possible answer field names used across flows
                'student_answer' => $answer->answer ?? $answer->answer_text ?? null,
                'correct_answer' => $question->correct_answer,
                'correct_answer_resolved' => $resolvedCorrectAnswer,
                'is_correct' => $answer->is_correct,
                'is_math' => (bool) ($question->is_math ?? false),
                'is_chemistry' => (bool) ($question->is_chemistry ?? false),
                'multiple_answers' => (bool) ($question->multiple_answers ?? false),
                // Prefer stored answer points, fallback to alternative fields or zero
                'points_earned' => $answer->points_earned === null ? null : $answer->points_earned,
                'pending_review' => $answer->points_earned === null && !in_array((int) $question->id, $excludedQuestionIds, true),
                // Use per-answer max if set, otherwise fall back to question marks or legacy max_points
                'max_points' => $answer->max_points ?? $question->marks ?? $question->max_points ?? 0,
                'explanation' => $question->explanation,
                'question_image' => $question->question_image_url,
                'correct_answer_image' => $question->correct_answer_image_url,
                'confidence_score' => $answer->confidence_score ?? null,
                'submitted_at' => $answer->submitted_at ?? $answer->created_at ?? null,
            ];
        }

        // Show the same question order the student saw during the attempt.
        if (!$learnerAttempt && is_array($studentAssessment->question_order)) {
            $positions = array_flip(array_map('intval', $studentAssessment->question_order));
            // A multipart parent's children share its position when only the
            // parent was directly attached to the assessment.
            foreach ($studentAnswers as $answer) {
                $qid = (int) $answer->question_id;
                $parentId = (int) ($answer->question?->parent_question_id ?? 0);
                if (!isset($positions[$qid]) && isset($positions[$parentId])) {
                    $positions[$qid] = $positions[$parentId];
                }
            }
            usort($results['questions'], fn ($a, $b) =>
                ($positions[(int) $a['question_id']] ?? PHP_INT_MAX)
                <=> ($positions[(int) $b['question_id']] ?? PHP_INT_MAX)
            );
        }

        return response()->json($results);
    }

    public function getPracticeQuestions(Request $request)
    {
        $request->validate([
            'topic_id' => 'required|exists:topics,id',
            'mode' => 'required|in:all,custom,unpracticed',
            'limit' => 'required_if:mode,custom,unpracticed|integer|min:1'
        ]);

        $topicId = $request->topic_id;
        $mode = $request->mode;
        $studentId = auth()->id(); // Assume authenticated student

        if ($mode === 'all') {
            $questions = Question::where('topic_id', $topicId)
                ->whereDoesntHave('subQuestions')
                ->get();
        } elseif ($mode === 'custom') {
            $questions = Question::where('topic_id', $topicId)
                ->whereDoesntHave('subQuestions')
                ->inRandomOrder()
                ->take($request->limit)
                ->get();
        } else {
            // Unpracticed questions only
            $practicedQuestionIds = StudentQuestionHistory::where('student_id', $studentId)
                ->pluck('question_id');

            $questions = Question::where('topic_id', $topicId)
                ->whereDoesntHave('subQuestions')
                ->whereNotIn('id', $practicedQuestionIds)
                ->inRandomOrder()
                ->take($request->limit)
                ->get();
        }

        return response()->json($questions);
    }
    public function reorderQuestions(Request $request, $id)
    {
        $request->validate([
            'questions' => 'required|array',
            'questions.*.id' => 'required|exists:assessment_questions,id',
            'questions.*.position' => 'required|integer|min:1',
        ]);
        $assessment = Assessment::findOrFail($id);
        $this->ensureQuestionEditingAllowed($assessment);
        $user = Auth::user();

        // Verify the user is the creator of the assessment
        if ($assessment->creator_id !== $user->id) {
            return response()->json([
                'message' => 'You are not authorized to reorder questions for this assessment.',
            ], 403);
        }

        try {
            DB::beginTransaction();
            foreach ($request->questions as $item) {
                AssessmentQuestion::where('id', $item['id'])
                    ->where('assessment_id', $id)
                    ->update(['order' => $item['position']]);
            }
            DB::commit();
            return response()->json([
                'message' => 'Questions reordered successfully',
                'assessment' => $assessment->load('questions')
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => 'Failed to reorder questions',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function assignedAssessments(Request $request)
    {
        $student = $request->user();

        // Get all group IDs the student belongs to
        $groupIds = $student->groups()->pluck('groups.id');

        $assignedAssessments = Assessment::with([
            'subject:id,name',
            'creator:id,name',
            'groups:id,group_name,class_code'
        ])
            // Only assessments assigned to the student's groups
            ->whereHas('groups', function ($query) use ($groupIds) {
                $query->whereIn('groups.id', $groupIds);
            })
            // Exclude assessments created by the student themselves
            ->where('creator_id', '!=', $student->id)
            ->orderByDesc('created_at')
            ->get();

        return response()->json($assignedAssessments);
    }


    /**
     * Render chemistry equations using KaTeX with mhchem extension
     *
     * @param string $latex The LaTeX content to render
     * @return string The rendered HTML
     */
    private function renderChemistry($latex)
    {
        // If the equation is not already wrapped in \ce{}, wrap it
        if (strpos($latex, '\\ce{') === false) {
            $latex = '\\ce{' . $latex . '}';
        }

        // Escape the LaTeX for shell execution
        $escapedLatex = escapeshellarg($latex);

        // Use KaTeX with the mhchem extension to render the chemistry equation
        // The --trust flag is needed to allow the mhchem extension
        // The --macros flag is used to define macros for chemistry notation
        $html = shell_exec("katex --trust --macros '{\"\\\\ce\":{\"\\\\ce\":\"true\"}}' $escapedLatex 2>&1");

        return $html ?: $latex;
    }

    public function practice(Request $request)
    {
        $studentId = $request->user()->id;

        $practice = Assessment::query()
            ->with([
                'creator:id,name',
                'gradeSubject.subject:id,name',
                'gradeSubject.topics:id,grade_subject_id,topic_name',
                'studentAssessments' => function ($q) use ($studentId) {
                    $q->where('student_id', $studentId)->latest('id')->limit(1);
                }
            ])
            ->where('type', 'practice')
            ->where('creator_id', $studentId)
            ->orderByDesc('created_at')
            ->paginate(5);

        $practice->getCollection()->transform(function ($assessment) {
            // attach student assessment
            $assessment->student_assessment = $assessment->studentAssessments->first();
            unset($assessment->studentAssessments);

            // attach subject + topic for frontend convenience
            $assessment->subject = $assessment->gradeSubject?->subject;                 // {id,name}
            $assessment->topic   = $assessment->gradeSubject?->topics?->first();        // {id,topic_name,...}

            unset($assessment->gradeSubject);

            return $assessment;
        });

        return response()->json($practice);
    }



    /**
     * Update teacher-editable assessment settings from the assessment
     * management page.
     *
     * System-generated personalized formative containers are intentionally
     * excluded because their lifecycle is controlled by the formative service.
     */
    public function updateSettings(Request $request, $id)
    {
        $user = Auth::user();

        $assessment = Assessment::query()
            ->withCount([
                'studentAssessments as started_attempts_count' => function ($query) {
                    // student_assessments does not have a started_at column.
                    // Assigned (pending) records are not started attempts.
                    $query->whereIn('status', [
                        'in_progress', 'completed', 'graded', 'under_review',
                    ]);
                },
            ])
            ->findOrFail($id);

        if ((int) $assessment->creator_id !== (int) $user->id) {
            return response()->json([
                'message' => 'You are not authorized to update this assessment.',
            ], 403);
        }

        if ($assessment->is_system_generated) {
            return response()->json([
                'message' => 'System-generated formative assessment settings are managed automatically.',
            ], 422);
        }

        if ($assessment->status === 'archived') {
            return response()->json([
                'message' => 'Restore this assessment before changing its settings.',
            ], 422);
        }

        $data = $request->validate([
            'type' => [
                'required',
                'in:quiz,exam,homework,test,assignment',
            ],
            'delivery_mode' => [
                'required',
                'in:online,offline',
            ],
            'is_timed' => [
                'required',
                'boolean',
            ],
            'time_limit' => [
                'nullable',
                'integer',
                'min:1',
                'max:600',
                'required_if:is_timed,true,1',
            ],
            'due_date' => [
                'nullable',
                'date',
            ],
            'shuffle_questions' => ['sometimes', 'boolean'],
            'shuffle_options' => ['sometimes', 'boolean'],
        ]);

        $started = (int) ($assessment->started_attempts_count ?? 0);

        if ($started > 0) {
            $lockedChanged =
                strtolower((string) $assessment->type) !== strtolower((string) $data['type'])
                || strtolower((string) ($assessment->delivery_mode ?? 'online')) !== strtolower((string) $data['delivery_mode'])
                || (array_key_exists('shuffle_questions', $data) && (bool) $assessment->shuffle_questions !== (bool) $data['shuffle_questions'])
                || (array_key_exists('shuffle_options', $data) && (bool) $assessment->shuffle_options !== (bool) $data['shuffle_options'])
                || (bool) $assessment->is_timed !== (bool) $data['is_timed']
                || (
                    (bool) $data['is_timed']
                    && (int) ($assessment->time_limit ?? 0) !== (int) ($data['time_limit'] ?? 0)
                );

            if ($lockedChanged) {
                return response()->json([
                    'message' => 'Type, delivery mode, and timing cannot be changed after a student has started this assessment. You can still adjust the due date.',
                ], 422);
            }
        }

        if (array_key_exists('shuffle_questions', $data)) $assessment->shuffle_questions = (bool) $data['shuffle_questions'];
        if (array_key_exists('shuffle_options', $data)) $assessment->shuffle_options = (bool) $data['shuffle_options'];
        $assessment->type = $data['type'];
        $assessment->delivery_mode = $data['delivery_mode'];
        $assessment->is_timed = (bool) $data['is_timed'];
        $assessment->time_limit = $assessment->is_timed
            ? (int) $data['time_limit']
            : null;
        $assessment->due_date = $data['due_date'] ?? null;
        $assessment->save();

        return response()->json([
            'message' => 'Assessment settings updated successfully.',
            'assessment' => $assessment->fresh(),
        ]);
    }

    public function archive(Request $request, $id)
    {
        $user = Auth::user();
        $assessment = Assessment::findOrFail($id);

        if ((int) $assessment->creator_id !== (int) $user->id) {
            return response()->json([
                'message' => 'You are not authorized to archive this assessment.',
            ], 403);
        }

        if ($assessment->is_system_generated) {
            return response()->json([
                'message' => 'System-generated formative assessments cannot be archived manually.',
            ], 422);
        }

        if ($assessment->status !== 'published') {
            return response()->json([
                'message' => 'Only published assessments can be archived from this page.',
            ], 422);
        }

        $assessment->status = 'archived';
        $assessment->save();

        return response()->json([
            'message' => 'Assessment archived successfully.',
            'assessment' => $assessment->fresh(),
        ]);
    }

    public function restore(Request $request, $id)
    {
        $user = Auth::user();
        $assessment = Assessment::findOrFail($id);

        if ((int) $assessment->creator_id !== (int) $user->id) {
            return response()->json([
                'message' => 'You are not authorized to restore this assessment.',
            ], 403);
        }

        if ($assessment->is_system_generated) {
            return response()->json([
                'message' => 'System-generated formative assessments are managed automatically.',
            ], 422);
        }

        if ($assessment->status !== 'archived') {
            return response()->json([
                'message' => 'This assessment is not archived.',
            ], 422);
        }

        /*
         * Assessments are only archived from the published state in this
         * management workflow, so restore returns them to published.
         */
        $assessment->status = 'published';
        $assessment->save();

        return response()->json([
            'message' => 'Assessment restored successfully.',
            'assessment' => $assessment->fresh(),
        ]);
    }

    /**
     * Delete an assessment by ID
     */
    public function destroy($id)
    {
        $user = Auth::user();
        $assessment = Assessment::findOrFail($id);
        // Only the creator can delete
        if ($assessment->creator_id !== $user->id) {
            return response()->json(['message' => 'You are not authorized to delete this assessment.'], 403);
        }

        // Count related topics and questions
        $topicCount = $assessment->topics()->count();
        $questionCount = $assessment->questions()->count();

        // Detach topics (assessment_topic pivot)
        $assessment->topics()->detach();
        // Delete assessment_questions
        $assessment->questions()->delete();

        // Delete the assessment
        $assessment->delete();

        return response()->json([
            'message' => 'Assessment and all related topics/questions deleted successfully.',
            'topics_unlinked' => $topicCount,
            'questions_deleted' => $questionCount
        ]);
    }
}
