<?php

namespace App\Services;

use App\Models\Assessment;
use App\Models\Group;
use App\Models\LearningPeriod;
use App\Models\StudentAssessment;
use App\Models\StudentAnswer;
use App\Models\StudentAnswerMarkReview;
use App\Models\TutorResponseEvaluation;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class TeacherGradebookService
{
    public function overview(User $teacher, array $filters = []): array
    {
        $this->ensureTeacherOrAdmin($teacher);

        $groups = $this->accessibleGroups($teacher, $filters);
        $groupIds = $groups->pluck('id')->all();
        $periods = $this->learningPeriods($groupIds);

        $students = $groups
            ->flatMap(fn (Group $group) => $group->students)
            ->unique('id')
            ->sortBy('name')
            ->values();

        $assessments = $this->assessmentColumns($groupIds, $filters);
        $checks = $this->understandingChecks($groupIds, $filters);

        $studentRows = $this->studentRows(
            $students,
            $groups,
            $assessments,
            $checks
        );

        $objectiveRows = $this->objectiveRows($checks);

        return [
            'filters' => [
                'group_id' => $filters['group_id'] ?? null,
                'grade_subject_id' => $filters['grade_subject_id'] ?? null,
                'assessment_type' => $filters['assessment_type'] ?? null,
                'learning_period_id' => $filters['learning_period_id'] ?? null,
                'from' => $filters['from'] ?? null,
                'to' => $filters['to'] ?? null,
            ],

            'available_filters' => [
                'groups' => $groups->map(fn (Group $group) => [
                    'id' => $group->id,
                    'name' => $group->group_name,
                    'academic_year' => $group->academic_year,
                    'grade_subject_id' => $group->grade_subject_id,
                    'subject' => $group->gradeSubject?->subject?->name,
                    'grade' => $group->gradeSubject?->gradeLevel?->grade_name,
                ])->values(),

                'teaching_areas' => $groups
                    ->filter(fn (Group $group) => $group->gradeSubject)
                    ->map(fn (Group $group) => [
                        'id' => $group->gradeSubject->id,
                        'label' => trim(implode(' - ', array_filter([
                            $group->gradeSubject?->subject?->name,
                            $group->gradeSubject?->gradeLevel?->grade_name,
                        ]))),
                    ])
                    ->unique('id')
                    ->values(),

                'learning_periods' => $periods->map(fn (LearningPeriod $period) => [
                    'id' => $period->id,
                    'title' => $period->title,
                    'group_id' => $period->group_id,
                    'group_name' => $period->group?->group_name,
                    'grade_subject_id' => $period->grade_subject_id,
                    'subject' => $period->gradeSubject?->subject?->name,
                    'grade' => $period->gradeSubject?->gradeLevel?->grade_name,
                    'start_date' => $period->start_date ? (string) $period->start_date : null,
                    'end_date' => $period->end_date ? (string) $period->end_date : null,
                    'period_state' => $this->periodState($period),
                ])->values(),

                'assessment_types' => [
                    ['value' => 'quiz', 'label' => 'Quiz'],
                    ['value' => 'exam', 'label' => 'Exam'],
                    ['value' => 'homework', 'label' => 'Homework'],
                    ['value' => 'practice', 'label' => 'Practice'],
                    ['value' => 'formative', 'label' => 'Formative'],
                ],
            ],

            'summary' => [
                'students' => $studentRows->count(),
                'assessments' => $assessments->count(),
                'understanding_checks' => $checks->count(),
                'assessment_average' => $this->average(
                    $studentRows->pluck('assessment_average')->filter(fn ($value) => $value !== null)
                ),
                'check_average' => $this->average(
                    $studentRows->pluck('check_average')->filter(fn ($value) => $value !== null)
                ),
                'students_needing_attention' => $studentRows
                    ->filter(fn ($row) => $row['needs_attention'])
                    ->count(),
            ],

            'period_summaries' => $this->periodSummaries($periods, $students, $assessments, $checks)->all(),
            'assessment_columns' => $assessments->values()->all(),
            'students' => $studentRows->values()->all(),
            'understanding_checks' => $checks->values()->all(),
            'objectives' => $objectiveRows->values()->all(),
        ];
    }

    public function exportRows(User $teacher, array $filters = []): array
    {
        $data = $this->overview($teacher, $filters);

        $columns = collect($data['assessment_columns']);

        $headings = [
            'Student',
            'Email',
            'Class(es)',
        ];

        foreach ($columns as $column) {
            $headings[] = $column['title'] . ' (' . $column['group_name'] . ')';
        }

        $headings[] = 'Assessment Average %';
        $headings[] = 'Understanding Check Average %';
        $headings[] = 'Understanding Checks Completed';
        $headings[] = 'Needs Attention';

        $rows = collect($data['students'])->map(function ($student) use ($columns) {
            $row = [
                $student['name'],
                $student['email'],
                implode(', ', $student['classes']),
            ];

            foreach ($columns as $column) {
                $score = $student['assessment_scores'][$column['key']] ?? null;

                if (!$score || $score['percentage'] === null) {
                    $row[] = '';
                    continue;
                }

                $row[] = $score['percentage'];
            }

            $row[] = $student['assessment_average'] ?? '';
            $row[] = $student['check_average'] ?? '';
            $row[] = $student['check_count'];
            $row[] = $student['needs_attention'] ? 'Yes' : 'No';

            return $row;
        })->all();

        return [
            'headings' => $headings,
            'rows' => $rows,
        ];
    }

    protected function accessibleGroups(User $teacher, array $filters = []): Collection
    {
        $query = Group::query()
            ->with([
                'students:id,name,email',
                'gradeSubject:id,subject_id,grade_level_id',
                'gradeSubject.subject:id,name',
                'gradeSubject.gradeLevel:id,grade_name',
                'creator:id,school_id',
            ]);

        if ($teacher->role === 'admin') {
            $query->where(function ($q) use ($teacher) {
                $q->whereHas('creator', function ($creator) use ($teacher) {
                    $creator->where('school_id', $teacher->school_id);
                })->orWhereHas('gradeSubject', function ($gradeSubject) use ($teacher) {
                    $gradeSubject->where('school_id', $teacher->school_id);
                });
            });
        } else {
            $query->where('created_by', $teacher->id);
        }

        if (!empty($filters['group_id'])) {
            $query->whereKey((int) $filters['group_id']);
        }

        if (!empty($filters['grade_subject_id'])) {
            $query->where('grade_subject_id', (int) $filters['grade_subject_id']);
        }

        return $query
            ->orderBy('group_name')
            ->get();
    }

    protected function assessmentColumns(array $groupIds, array $filters = []): Collection
    {
        if (empty($groupIds)) {
            return collect();
        }

        $query = Assessment::query()
            ->whereHas('groups', fn ($q) => $q->whereIn('groups.id', $groupIds))
            ->with([
                'groups' => fn ($q) => $q
                    ->whereIn('groups.id', $groupIds)
                    ->select('groups.id', 'group_name', 'grade_subject_id', 'academic_year'),
                'assessmentQuestions.question:id,marks',
                'studentAssessments:id,student_id,assessment_id,score,max_score,status,completed_at',
            ])
            ->orderByDesc('created_at');

        if (!empty($filters['assessment_type'])) {
            $query->where('type', $filters['assessment_type']);
        }

        if (!empty($filters['learning_period_id'])) {
            $query->where('learning_period_id', (int) $filters['learning_period_id']);
        }

        $from = $filters['from'] ?? null;
        $to = $filters['to'] ?? null;

        if ($from) {
            $query->whereDate('created_at', '>=', $from);
        }

        if ($to) {
            $query->whereDate('created_at', '<=', $to);
        }

        $assessments = $query->get();

        return $assessments->flatMap(function (Assessment $assessment) {
            $questionMax = $assessment->assessmentQuestions
                ->sum(fn ($aq) => (float) ($aq->question?->marks ?? 0));

            return $assessment->groups->map(function ($group) use ($assessment, $questionMax) {
                $attempts = $assessment->studentAssessments
                    ->keyBy('student_id');

                return [
                    'key' => $assessment->id . '-' . $group->id,
                    'assessment_id' => $assessment->id,
                    'learning_period_id' => $assessment->learning_period_id,
                    'group_id' => $group->id,
                    'group_name' => $group->group_name,
                    'title' => $assessment->title,
                    'type' => $assessment->type,
                    'delivery_mode' => $assessment->delivery_mode,
                    'due_date' => $assessment->due_date ? (string) $assessment->due_date : null,
                    'max_score' => round($questionMax, 2),
                    'attempts' => $attempts,
                ];
            });
        })->values();
    }

    protected function understandingChecks(array $groupIds, array $filters = []): Collection
    {
        if (empty($groupIds)) {
            return collect();
        }

        $query = TutorResponseEvaluation::query()
            ->whereHas('session', fn ($q) => $q->whereIn('group_id', $groupIds))
            ->with([
                'student:id,name,email',
                'session:id,group_id,topic_id,learning_period_id',
                'session.group:id,group_name',
                'session.topic:id,topic_name,unit_id',
                'session.topic.unit:id,name',
                'sessionObjective:id,learning_objective_id,tutor_session_id',
                'sessionObjective.learningObjective:id,topic_id,code,objective',
            ])
            ->orderByDesc('created_at');

        if (!empty($filters['group_id'])) {
            $groupId = (int) $filters['group_id'];
            $query->whereHas('session', fn ($q) => $q->where('group_id', $groupId));
        }

        if (!empty($filters['grade_subject_id'])) {
            $gradeSubjectId = (int) $filters['grade_subject_id'];
            $query->whereHas('session', fn ($q) => $q->where('grade_subject_id', $gradeSubjectId));
        }

        if (!empty($filters['learning_period_id'])) {
            $learningPeriodId = (int) $filters['learning_period_id'];
            $query->whereHas('session', fn ($q) => $q->where('learning_period_id', $learningPeriodId));
        }

        if (!empty($filters['from'])) {
            $query->whereDate('created_at', '>=', $filters['from']);
        }

        if (!empty($filters['to'])) {
            $query->whereDate('created_at', '<=', $filters['to']);
        }

        return $query->get()->map(function (TutorResponseEvaluation $evaluation) {
            $objective = $evaluation->sessionObjective?->learningObjective;
            $topic = $evaluation->session?->topic;

            return [
                'id' => $evaluation->id,
                'student_id' => $evaluation->student_id,
                'student_name' => $evaluation->student?->name,
                'group_id' => $evaluation->session?->group_id,
                'group_name' => $evaluation->session?->group?->group_name,
                'learning_period_id' => $evaluation->session?->learning_period_id,
                'unit' => $topic?->unit?->name,
                'topic' => $topic?->topic_name,
                'learning_objective_id' => $objective?->id,
                'objective_code' => $objective?->code,
                'objective' => $objective?->objective,
                'classification' => $evaluation->classification,
                'correct' => (bool) $evaluation->correct,
                'score' => (int) $evaluation->understanding_score,
                'misconception' => $evaluation->misconception,
                'created_at' => optional($evaluation->created_at)->toDateTimeString(),
            ];
        })->values();
    }

    protected function studentRows(
        Collection $students,
        Collection $groups,
        Collection $assessments,
        Collection $checks
    ): Collection {
        $studentGroupMap = [];

        foreach ($groups as $group) {
            foreach ($group->students as $student) {
                $studentGroupMap[$student->id][] = [
                    'id' => $group->id,
                    'name' => $group->group_name,
                ];
            }
        }

        return $students->map(function (User $student) use (
            $studentGroupMap,
            $assessments,
            $checks
        ) {
            $classes = collect($studentGroupMap[$student->id] ?? []);
            $classIds = $classes->pluck('id')->all();

            $assessmentScores = [];
            $assessmentPercentages = collect();

            foreach ($assessments as $column) {
                if (!in_array($column['group_id'], $classIds, true)) {
                    continue;
                }

                /** @var StudentAssessment|null $attempt */
                $attempt = $column['attempts']->get($student->id);

                if (!$attempt) {
                    $assessmentScores[$column['key']] = [
                        'status' => 'not_started',
                        'score' => null,
                        'max_score' => $column['max_score'],
                        'percentage' => null,
                    ];
                    continue;
                }

                $maxScore = (float) $attempt->max_score > 0
                    ? (float) $attempt->max_score
                    : (float) $column['max_score'];

                $percentage = $maxScore > 0 && !in_array($attempt->status, ['under_review'], true) && $attempt->score !== null
                    ? round(((float) $attempt->score / $maxScore) * 100, 1)
                    : null;

                $assessmentScores[$column['key']] = [
                    'status' => $attempt->status,
                    'score' => $attempt->score === null ? null : round((float) $attempt->score, 2),
                    'max_score' => round($maxScore, 2),
                    'percentage' => $percentage,
                    'completed_at' => optional($attempt->completed_at)->toDateTimeString(),
                ];

                if ($percentage !== null && in_array($attempt->status, ['graded', 'completed'], true)) {
                    $assessmentPercentages->push($percentage);
                }
            }

            $studentChecks = $checks
                ->where('student_id', $student->id)
                ->values();

            $checkAverage = $this->average($studentChecks->pluck('score'));
            $assessmentAverage = $this->average($assessmentPercentages);

            $latestCheck = $studentChecks->first();

            $needsAttention = (
                $checkAverage !== null && $checkAverage < 50
            ) || (
                $assessmentAverage !== null && $assessmentAverage < 50
            ) || $studentChecks->contains(fn ($check) => !empty($check['misconception']));

            return [
                'id' => $student->id,
                'name' => $student->name,
                'email' => $student->email,
                'classes' => $classes->pluck('name')->values()->all(),
                'assessment_scores' => $assessmentScores,
                'assessment_average' => $assessmentAverage,
                'assessment_count' => $assessmentPercentages->count(),
                'check_average' => $checkAverage,
                'check_count' => $studentChecks->count(),
                'latest_check_score' => $latestCheck['score'] ?? null,
                'latest_check_at' => $latestCheck['created_at'] ?? null,
                'needs_attention' => $needsAttention,
            ];
        });
    }

    protected function objectiveRows(Collection $checks): Collection
    {
        return $checks
            ->filter(fn ($check) => !empty($check['learning_objective_id']))
            ->groupBy('learning_objective_id')
            ->map(function (Collection $rows) {
                $first = $rows->first();
                $scores = $rows->pluck('score');

                return [
                    'learning_objective_id' => $first['learning_objective_id'],
                    'code' => $first['objective_code'],
                    'objective' => $first['objective'],
                    'topic' => $first['topic'],
                    'unit' => $first['unit'],
                    'attempts' => $rows->count(),
                    'students' => $rows->pluck('student_id')->unique()->count(),
                    'average_score' => $this->average($scores),
                    'mastery_rate' => $rows->count() > 0
                        ? round(($rows->where('score', '>=', 80)->count() / $rows->count()) * 100, 1)
                        : null,
                ];
            })
            ->sortBy('unit')
            ->sortBy('topic')
            ->values();
    }



    public function studentProfile(User $teacher, User $student, array $filters = []): array
    {
        $this->ensureTeacherOrAdmin($teacher);

        $groups = $this->accessibleGroups($teacher, $filters)
            ->filter(fn (Group $group) => $group->students->contains('id', $student->id))
            ->values();

        abort_if(
            $groups->isEmpty(),
            403,
            'This student is not enrolled in a class you can manage.'
        );

        $groupIds = $groups->pluck('id')->all();

        $attemptQuery = StudentAssessment::query()
            ->where('student_id', $student->id)
            ->whereHas('assessment.groups', fn ($q) => $q->whereIn('groups.id', $groupIds));

        if (!empty($filters['assessment_type'])) {
            $attemptQuery->whereHas('assessment', fn ($q) =>
                $q->where('type', $filters['assessment_type'])
            );
        }

        if (!empty($filters['learning_period_id'])) {
            $attemptQuery->whereHas('assessment', fn ($q) =>
                $q->where('learning_period_id', (int) $filters['learning_period_id'])
            );
        }

        if (!empty($filters['from'])) {
            $attemptQuery->whereDate('completed_at', '>=', $filters['from']);
        }

        if (!empty($filters['to'])) {
            $attemptQuery->whereDate('completed_at', '<=', $filters['to']);
        }

        $attempts = $attemptQuery
            ->with([
                'assessment:id,title,type,purpose,creator_id,due_date,delivery_mode,status,learning_period_id',
                'assessment.learningPeriod:id,title,start_date,end_date',
                'assessment.groups' => fn ($q) => $q
                    ->whereIn('groups.id', $groupIds)
                    ->select('groups.id', 'group_name', 'grade_subject_id', 'academic_year'),
                'assessment.assessmentQuestions.question:id,marks',
                'studentAnswers.question:id,question_type,question,options,marks,correct_answer,explanation,question_image,correct_answer_image,learning_objective_id',
                'studentAnswers.question.learningObjective:id,code,objective',
                'studentAnswers.reviewedBy:id,name',
                'studentAnswers.markReviews.reviewer:id,name',
            ])
            ->orderByDesc('completed_at')
            ->orderByDesc('assigned_at')
            ->get()
            ->map(function (StudentAssessment $attempt) {
                $fallbackMax = $attempt->assessment?->assessmentQuestions
                    ?->sum(fn ($aq) => (float) ($aq->question?->marks ?? 0)) ?? 0;

                $maxScore = (float) $attempt->max_score > 0
                    ? (float) $attempt->max_score
                    : (float) $fallbackMax;

                $percentage = $maxScore > 0
                    ? round(((float) $attempt->score / $maxScore) * 100, 1)
                    : null;

                return [
                    'id' => $attempt->id,
                    'assessment_id' => $attempt->assessment_id,
                    'title' => $attempt->assessment?->title,
                    'type' => $attempt->assessment?->type,
                    'purpose' => $attempt->assessment?->purpose,
                    'learning_period_id' => $attempt->assessment?->learning_period_id,
                    'learning_period' => $attempt->assessment?->learningPeriod?->title,
                    'is_formative' => $attempt->assessment?->type === 'formative',
                    'delivery_mode' => $attempt->assessment?->delivery_mode,
                    'status' => $attempt->status,
                    'score' => $attempt->score === null ? null : round((float) $attempt->score, 2),
                    'max_score' => round($maxScore, 2),
                    'percentage' => $attempt->status === 'under_review' ? null : $percentage,
                    'assigned_at' => optional($attempt->assigned_at)->toDateTimeString(),
                    'completed_at' => optional($attempt->completed_at)->toDateTimeString(),
                    'classes' => $attempt->assessment?->groups?->pluck('group_name')->values()->all() ?? [],
                    'answers' => $attempt->studentAnswers->map(function (StudentAnswer $answer) {
                        $question = $answer->question;

                        $reviews = $answer->markReviews ?? collect();
                        $firstReview = $reviews->first();

                        return [
                            'id' => $answer->id,
                            'question_id' => $answer->question_id,
                            'question_type' => $question?->question_type,
                            'question' => $question?->question,
                            'question_image_url' => $question?->question_image_url,
                            'options' => $question?->options,
                            'correct_answer' => $question?->correct_answer,
                            'explanation' => $question?->explanation,
                            'answer' => $answer->answer,
                            'system_points' => $firstReview ? ($firstReview->previous_is_correct === null ? null : (float) $firstReview->previous_points) : ($answer->points_earned === null ? null : (float) $answer->points_earned),
                            'points_earned' => $answer->points_earned === null ? null : (float) $answer->points_earned,
                            'marks' => (float) ($question?->marks ?? 0),
                            'is_correct' => $answer->is_correct,
                            'reviewed_at' => optional($answer->reviewed_at)->toDateTimeString(),
                            'reviewed_by' => $answer->reviewedBy?->name,
                            'teacher_feedback' => $answer->teacher_feedback,
                            'review_count' => $reviews->count(),
                            'review_history' => $reviews->map(fn ($review) => [
                                'id' => $review->id,
                                'previous_points' => (float) $review->previous_points,
                                'new_points' => (float) $review->new_points,
                                'feedback' => $review->feedback,
                                'reviewed_by' => $review->reviewer?->name,
                                'reviewed_at' => optional($review->created_at)->toDateTimeString(),
                            ])->values()->all(),
                            'objective_code' => $question?->learningObjective?->code,
                            'objective' => $question?->learningObjective?->objective,
                        ];
                    })->values()->all(),
                ];
            });

        $checks = $this->understandingChecks($groupIds, $filters)
            ->where('student_id', $student->id)
            ->values();

        $assessmentPercentages = $attempts
            ->pluck('percentage')
            ->filter(fn ($value) => $value !== null);

        return [
            'student' => [
                'id' => $student->id,
                'name' => $student->name,
                'email' => $student->email,
            ],
            'classes' => $groups->map(fn (Group $group) => [
                'id' => $group->id,
                'name' => $group->group_name,
                'academic_year' => $group->academic_year,
                'subject' => $group->gradeSubject?->subject?->name,
                'grade' => $group->gradeSubject?->gradeLevel?->grade_name,
            ])->values()->all(),
            'summary' => [
                'assessment_average' => $this->average($assessmentPercentages),
                'assessments_completed' => $attempts
                    ->filter(fn ($row) => in_array($row['status'], ['graded', 'completed'], true))
                    ->count(),
                'check_average' => $this->average($checks->pluck('score')),
                'checks_completed' => $checks->count(),
                'misconceptions' => $checks->filter(fn ($row) => !empty($row['misconception']))->count(),
            ],
            'assessments' => $attempts->values()->all(),
            'understanding_checks' => $checks->values()->all(),
        ];
    }

    public function manualReviewQueue(User $teacher, array $filters = []): Collection
    {
        $this->ensureTeacherOrAdmin($teacher);

        $groups = $this->accessibleGroups($teacher, $filters);
        $groupIds = $groups->pluck('id')->all();

        if (empty($groupIds)) {
            return collect();
        }

        $query = StudentAnswer::query()
            ->whereNull('reviewed_at')
            ->whereHas('question', fn ($q) => $q->where('question_type', 'open_ended'))
            ->whereHas('studentAssessment', function ($q) use ($groupIds, $filters) {
                $q->where('status', 'under_review')
                    ->whereHas('assessment.groups', fn ($g) => $g->whereIn('groups.id', $groupIds));

                if (!empty($filters['assessment_type'])) {
                    $q->whereHas('assessment', fn ($assessment) =>
                        $assessment->where('type', $filters['assessment_type'])
                    );
                }

                if (!empty($filters['learning_period_id'])) {
                    $q->whereHas('assessment', fn ($assessment) =>
                        $assessment->where('learning_period_id', (int) $filters['learning_period_id'])
                    );
                }

                if (!empty($filters['from'])) {
                    $q->whereDate('completed_at', '>=', $filters['from']);
                }

                if (!empty($filters['to'])) {
                    $q->whereDate('completed_at', '<=', $filters['to']);
                }
            });

        return $query
            ->with([
                'question:id,question_type,question,marks,question_image,learning_objective_id',
                'question.learningObjective:id,code,objective',
                'studentAssessment:id,student_id,assessment_id,status,score,max_score,completed_at',
                'studentAssessment.student:id,name,email',
                'studentAssessment.assessment:id,title,type,creator_id',
                'studentAssessment.assessment.groups' => fn ($q) => $q
                    ->whereIn('groups.id', $groupIds)
                    ->select('groups.id', 'group_name'),
            ])
            ->orderBy('student_assessment_id')
            ->orderBy('id')
            ->get()
            ->map(function (StudentAnswer $answer) {
                $question = $answer->question;
                $attempt = $answer->studentAssessment;

                return [
                    'answer_id' => $answer->id,
                    'student_assessment_id' => $attempt?->id,
                    'student_id' => $attempt?->student_id,
                    'student_name' => $attempt?->student?->name,
                    'student_email' => $attempt?->student?->email,
                    'assessment_id' => $attempt?->assessment_id,
                    'assessment_title' => $attempt?->assessment?->title,
                    'assessment_type' => $attempt?->assessment?->type,
                    'classes' => $attempt?->assessment?->groups?->pluck('group_name')->values()->all() ?? [],
                    'question_id' => $answer->question_id,
                    'question' => $question?->question,
                    'question_image_url' => $question?->question_image_url,
                    'answer' => $answer->answer,
                    'marks' => (float) ($question?->marks ?? 0),
                    'objective_code' => $question?->learningObjective?->code,
                    'objective' => $question?->learningObjective?->objective,
                    'completed_at' => optional($attempt?->completed_at)->toDateTimeString(),
                ];
            })
            ->values();
    }

    public function reviewAnswer(
        User $teacher,
        StudentAnswer $answer,
        float $points,
        ?string $feedback = null
    ): array {
        $this->ensureTeacherOrAdmin($teacher);

        $answer->loadMissing([
            'question:id,question_type,marks',
            'studentAssessment.assessment.groups:id,group_name,created_by,grade_subject_id',
        ]);

        // The legacy manual-marking queue must honor the publication gate too.
        // Otherwise it could publish an assigned score before all questions are reviewed.
        if (!in_array($answer->studentAssessment?->assessment?->type, ['formative', 'practice'], true)) {
            return $this->reviewAssignedAnswer($teacher, $answer, $points, $feedback);
        }

        abort_unless(
            $answer->question?->question_type === 'open_ended',
            422,
            'Only open-ended answers are manually graded in this queue.'
        );

        $accessibleGroupIds = $this->accessibleGroups($teacher)->pluck('id');
        $answerGroupIds = $answer->studentAssessment?->assessment?->groups?->pluck('id') ?? collect();
        abort_if($answerGroupIds->intersect($accessibleGroupIds)->isEmpty(), 403, 'You are not authorized to grade this response.');

        $maxMarks = (float) ($answer->question?->marks ?? 0);

        abort_if(
            $points < 0 || $points > $maxMarks,
            422,
            'Points must be between 0 and ' . $maxMarks . '.'
        );

        $answer->update([
            'points_earned' => $points,
            'is_correct' => $maxMarks > 0 && $points >= $maxMarks,
            'reviewed_by' => $teacher->id,
            'reviewed_at' => now(),
            'teacher_feedback' => $feedback ? trim($feedback) : null,
        ]);

        $attempt = $answer->studentAssessment()->with('assessment.assessmentQuestions.question')->firstOrFail();

        // The final score is not released until every pending question is marked,
        // including short answers assessed in the formative review workspace.
        $remaining = $attempt->studentAnswers()->whereNull('points_earned')->count();

        $score = (float) $attempt->studentAnswers()->sum('points_earned');
        $maxScore = (float) $attempt->assessment->assessmentQuestions
            ->sum(fn ($aq) => (float) ($aq->question?->marks ?? 0));

        $attempt->update([
            'score' => $remaining === 0 ? $score : null,
            'max_score' => $maxScore,
            'status' => $remaining === 0 ? 'graded' : 'under_review',
        ]);

        return [
            'answer_id' => $answer->id,
            'points_earned' => (float) $answer->points_earned,
            'reviewed_at' => optional($answer->reviewed_at)->toDateTimeString(),
            'student_assessment_id' => $attempt->id,
            'assessment_status' => $attempt->status,
            'assessment_score' => $attempt->score === null ? null : (float) $attempt->score,
            'assessment_max_score' => (float) $attempt->max_score,
            'remaining_manual_answers' => $remaining,
        ];
    }


    public function formativeReview(User $teacher, array $filters = []): Collection
    {
        $this->ensureTeacherOrAdmin($teacher);

        $groups = $this->accessibleGroups($teacher, $filters);
        $groupIds = $groups->pluck('id')->all();

        if (empty($groupIds)) {
            return collect();
        }

        $query = StudentAssessment::query()
            ->whereHas('assessment', function ($assessment) use ($groupIds, $filters) {
                $assessment
                    ->where('type', 'formative')
                    ->whereHas('groups', fn ($g) => $g->whereIn('groups.id', $groupIds));

            })
            ->whereIn('status', ['completed', 'graded', 'under_review']);

        if (!empty($filters['from'])) {
            $query->whereDate('completed_at', '>=', $filters['from']);
        }

        if (!empty($filters['to'])) {
            $query->whereDate('completed_at', '<=', $filters['to']);
        }

        if (!empty($filters['learning_period_id'])) {
            $query->whereHas('assessment', fn ($assessment) =>
                $assessment->where('learning_period_id', (int) $filters['learning_period_id'])
            );
        }

        return $query
            ->with([
                'student:id,name,email',
                'assessment:id,title,type,purpose,learning_period_id',
                'assessment.learningPeriod:id,title',
                'assessment.groups' => fn ($q) => $q
                    ->whereIn('groups.id', $groupIds)
                    ->select('groups.id', 'group_name'),
                'studentAnswers.question:id,question_type,question,options,correct_answer,marks,explanation,question_image,learning_objective_id',
                'studentAnswers.question.learningObjective:id,code,objective',
                'studentAnswers.reviewedBy:id,name',
                'studentAnswers.markReviews.reviewer:id,name',
            ])
            ->orderByDesc('completed_at')
            ->orderByDesc('id')
            ->get()
            ->map(function (StudentAssessment $attempt) {
                $answers = $attempt->studentAnswers
                    ->sortBy('id')
                    ->map(function (StudentAnswer $answer) {
                        $question = $answer->question;
                        $reviews = $answer->markReviews ?? collect();
                        $firstReview = $reviews->first();

                        return [
                            'answer_id' => $answer->id,
                            'question_id' => $answer->question_id,
                            'question_type' => $question?->question_type,
                            'question' => $question?->question,
                            'question_image_url' => $question?->question_image_url,
                            'options' => $question?->options,
                            'correct_answer' => $question?->correct_answer,
                            'explanation' => $question?->explanation,
                            'marks' => (float) ($question?->marks ?? 0),
                            'student_answer' => $answer->answer,
                            'system_points' => $firstReview ? ($firstReview->previous_is_correct === null ? null : (float) $firstReview->previous_points) : ($answer->points_earned === null ? null : (float) $answer->points_earned),
                            'current_points' => $answer->points_earned === null ? null : (float) $answer->points_earned,
                            'system_is_correct' => $firstReview
                                ? $firstReview->previous_is_correct
                                : $answer->is_correct,
                            'current_is_correct' => $answer->is_correct,
                            'teacher_feedback' => $answer->teacher_feedback,
                            'reviewed_at' => optional($answer->reviewed_at)->toDateTimeString(),
                            'reviewed_by' => $answer->reviewedBy?->name,
                            'review_count' => $reviews->count(),
                            'objective_code' => $question?->learningObjective?->code,
                            'objective' => $question?->learningObjective?->objective,
                            'review_history' => $reviews->map(fn ($review) => [
                                'id' => $review->id,
                                'previous_points' => (float) $review->previous_points,
                                'new_points' => (float) $review->new_points,
                                'feedback' => $review->feedback,
                                'reviewed_by' => $review->reviewer?->name,
                                'reviewed_at' => optional($review->created_at)->toDateTimeString(),
                            ])->values()->all(),
                        ];
                    })
                    ->values();

                return [
                    'student_assessment_id' => $attempt->id,
                    'student_id' => $attempt->student_id,
                    'student_name' => $attempt->student?->name,
                    'student_email' => $attempt->student?->email,
                    'assessment_id' => $attempt->assessment_id,
                    'assessment_title' => $attempt->assessment?->title,
                    'assessment_purpose' => $attempt->assessment?->purpose,
                    'learning_period' => $attempt->assessment?->learningPeriod?->title,
                    'classes' => $attempt->assessment?->groups?->pluck('group_name')->values()->all() ?? [],
                    'status' => $attempt->status,
                    'score' => $attempt->score === null ? null : (float) $attempt->score,
                    'max_score' => (float) ($attempt->max_score ?? 0),
                    'completed_at' => optional($attempt->completed_at)->toDateTimeString(),
                    'answers' => $answers->all(),
                    'pending_review_count' => $answers->filter(fn ($item) => $item['current_points'] === null)->count(),
                    'reviewed_answers' => $answers->where('review_count', '>', 0)->count(),
                    'answer_count' => $answers->count(),
                ];
            })
            ->values();
    }

    /**
     * Record a teacher's assessment of an assigned response without exposing a score.
     * This applies to auto-graded and ungraded responses alike.
     */
    public function reviewAssignedAnswer(User $teacher, StudentAnswer $answer, float $points, ?string $feedback = null): array
    {
        $this->ensureTeacherOrAdmin($teacher);

        return DB::transaction(function () use ($teacher, $answer, $points, $feedback) {
            $answer = StudentAnswer::query()->lockForUpdate()->findOrFail($answer->id);
            $answer->load(['question:id,marks', 'studentAssessment.assessment.groups:id,group_name,created_by,grade_subject_id']);
            $attempt = $answer->studentAssessment;
            $assessment = $attempt?->assessment;
            abort_unless($attempt && $assessment && !in_array($assessment->type, ['formative', 'practice'], true), 422, 'Use the formative review workspace for formative assessments.');
            abort_unless(in_array($attempt->status, ['under_review', 'graded'], true), 422, 'Only submitted assessment responses can be reviewed.');
            $accessibleIds = $this->accessibleGroups($teacher)->pluck('id');
            abort_if(($assessment->groups?->pluck('id') ?? collect())->intersect($accessibleIds)->isEmpty(), 403, 'You cannot review this assessment.');

            $max = (float) ($answer->question?->marks ?? 0);
            abort_if(!is_finite($points) || $points < 0 || $points > $max, 422, "Mark must be between 0 and {$max}.");
            $previousPoints = (float) ($answer->points_earned ?? 0);
            $previousCorrect = $answer->is_correct;
            $newCorrect = $max > 0 && $points >= $max;

            StudentAnswerMarkReview::create([
                'student_answer_id' => $answer->id,
                'student_assessment_id' => $attempt->id,
                'reviewed_by' => $teacher->id,
                'previous_points' => $previousPoints,
                'new_points' => $points,
                'previous_is_correct' => $previousCorrect,
                'new_is_correct' => $newCorrect,
                'feedback' => $feedback ? trim($feedback) : null,
            ]);
            $answer->update([
                'points_earned' => round($points, 2),
                'is_correct' => $newCorrect,
                'reviewed_by' => $teacher->id,
                'reviewed_at' => now(),
                'teacher_feedback' => $feedback ? trim($feedback) : null,
            ]);

            // A previously published legacy assessment stays published when corrected.
            // Unpublished assessments remain under review until an explicit publish action.
            if ($attempt->status === 'graded') {
                $attempt->update(['score' => round((float) $attempt->studentAnswers()->sum('points_earned'), 2)]);
            }

            return [
                'answer_id' => $answer->id,
                'points_earned' => (float) $answer->points_earned,
                'reviewed_at' => $answer->reviewed_at?->toDateTimeString(),
                'assessment_status' => $attempt->status,
                'assessment_score' => $attempt->status === 'graded' ? (float) $attempt->score : null,
                'assessment_max_score' => (float) $attempt->max_score,
            ];
        });
    }

    /** Publish assigned results once all genuinely ungraded responses have marks. */
    public function publishAssignedResults(User $teacher, StudentAssessment $attempt): array
    {
        $this->ensureTeacherOrAdmin($teacher);

        return DB::transaction(function () use ($teacher, $attempt) {
            $attempt = StudentAssessment::query()->lockForUpdate()->findOrFail($attempt->id);
            $attempt->load('assessment.groups:id,group_name,created_by,grade_subject_id');
            $assessment = $attempt->assessment;
            abort_unless($assessment && !in_array($assessment->type, ['formative', 'practice'], true), 422, 'Only assigned assessments can be published here.');
            $accessibleIds = $this->accessibleGroups($teacher)->pluck('id');
            abort_if(($assessment->groups?->pluck('id') ?? collect())->intersect($accessibleIds)->isEmpty(), 403, 'You cannot publish this assessment.');
            abort_unless($attempt->status === 'under_review', 422, 'The assessment must be awaiting review.');

            $answers = $attempt->studentAnswers()->get();
            abort_if($answers->isEmpty(), 422, 'No submitted answers to publish.');
            $ungraded = $answers->filter(fn ($answer) => $answer->points_earned === null)->count();
            abort_if($ungraded > 0, 422, "Grade the {$ungraded} unmarked response(s) before publishing. Automatically graded answers do not require confirmation.");
            $score = round((float) $answers->sum('points_earned'), 2);
            $attempt->update(['score' => $score, 'status' => 'graded']);
            return ['student_assessment_id' => $attempt->id, 'assessment_status' => 'graded', 'assessment_score' => $score, 'assessment_max_score' => (float) $attempt->max_score];
        });
    }


    /** Assessment-wide summary used by the review queue; no student scores are exposed. */
    public function assignedPublicationStatus(User $teacher, Assessment $assessment, ?int $groupId = null): array
    {
        $this->ensureTeacherOrAdmin($teacher);
        abort_if(in_array($assessment->type, ['formative', 'practice'], true), 422, 'This is not an assigned assessment.');
        $accessibleGroups = $this->accessibleGroups($teacher);
        $assignedGroups = $assessment->groups()->whereIn('groups.id', $accessibleGroups->pluck('id'))->get();
        abort_if($assignedGroups->isEmpty(), 403, 'You cannot review this assessment.');
        if ($groupId !== null) {
            abort_if(!$assignedGroups->contains('id', $groupId), 403, 'This assessment is not assigned to that class.');
            $assignedGroups = $assignedGroups->where('id', $groupId);
        }
        $studentIds = $assignedGroups->flatMap(fn ($group) => $group->students->pluck('id'))->unique()->values();
        $attempts = StudentAssessment::query()
            ->where('assessment_id', $assessment->id)
            ->whereIn('student_id', $studentIds)
            ->whereIn('status', ['under_review', 'graded'])
            ->with('studentAnswers:id,student_assessment_id,points_earned')
            ->get();
        $pending = $attempts->where('status', 'under_review');
        $ready = $pending->filter(fn ($a) => $a->studentAnswers->isNotEmpty() &&
            $a->studentAnswers->every(fn ($answer) => $answer->points_earned !== null));
        return [
            'assessment_id' => $assessment->id,
            'submitted' => $attempts->count(),
            'already_published' => $attempts->where('status', 'graded')->count(),
            'awaiting_publication' => $pending->count(),
            'ready' => $ready->count(),
            'needs_marking' => $pending->count() - $ready->count(),
            'ready_student_ids' => $ready->pluck('student_id')->values()->all(),
            'pending_student_ids' => $pending->pluck('student_id')->values()->all(),
        ];
    }

    /** Publish all reviewed submissions in one transaction; never release partial results. */
    public function publishAllAssignedResults(User $teacher, Assessment $assessment, ?int $groupId = null): array
    {
        return DB::transaction(function () use ($teacher, $assessment, $groupId) {
            // The same authorization and class scope are checked inside the transaction.
            $status = $this->assignedPublicationStatus($teacher, $assessment, $groupId);
            abort_if($status['awaiting_publication'] === 0, 422, 'There are no unpublished submissions for this assessment.');
            abort_if($status['needs_marking'] > 0, 422,
                $status['needs_marking'] . ' submission(s) still contain ungraded responses.');
            $attempts = StudentAssessment::query()
                ->where('assessment_id', $assessment->id)
                ->whereIn('student_id', $status['pending_student_ids'])
                ->where('status', 'under_review')
                ->lockForUpdate()->get();
            abort_if($attempts->count() !== $status['awaiting_publication'], 409, 'Submissions changed. Refresh and retry.');
            foreach ($attempts as $attempt) {
                $answers = $attempt->studentAnswers()->get();
                abort_if($answers->isEmpty() || $answers->contains(fn ($a) => $a->points_earned === null),
                    409, 'One or more submissions are no longer ready for publication.');
                $attempt->update([
                    'score' => round((float) $answers->sum('points_earned'), 2),
                    'status' => 'graded',
                ]);
            }
            return ['assessment_id' => $assessment->id, 'published' => $attempts->count()];
        });
    }

    public function reviewFormativeAnswer(
        User $teacher,
        StudentAnswer $answer,
        float $points,
        ?string $feedback = null
    ): array {
        $this->ensureTeacherOrAdmin($teacher);

        $answer->loadMissing([
            'question:id,question_type,marks',
            'studentAssessment.assessment.groups:id,group_name,created_by,grade_subject_id',
            'studentAssessment.studentAnswers.question:id,marks',
        ]);

        $attempt = $answer->studentAssessment;
        $assessment = $attempt?->assessment;

        abort_unless(
            $attempt && $assessment && $assessment->type === 'formative',
            422,
            'This response is not part of a formative assessment.'
        );

        $accessibleGroupIds = $this->accessibleGroups($teacher)->pluck('id');
        $answerGroupIds = $assessment->groups?->pluck('id') ?? collect();
        abort_if(
            $answerGroupIds->intersect($accessibleGroupIds)->isEmpty(),
            403,
            'You are not authorized to review this response.'
        );

        $maxMarks = (float) ($answer->question?->marks ?? 0);
        abort_if(
            $points < 0 || $points > $maxMarks,
            422,
            'Points must be between 0 and ' . $maxMarks . '.'
        );

        $previousPoints = (float) ($answer->points_earned ?? 0);
        // The audit table retains a numerical previous mark for legacy compatibility;
        // null means pending and is also captured by previous_is_correct = null.
        $previousCorrect = $answer->is_correct;
        $newCorrect = $maxMarks > 0 && $points >= $maxMarks;

        DB::transaction(function () use (
            $answer,
            $attempt,
            $teacher,
            $points,
            $feedback,
            $previousPoints,
            $previousCorrect,
            $newCorrect
        ) {
            StudentAnswerMarkReview::create([
                'student_answer_id' => $answer->id,
                'student_assessment_id' => $attempt->id,
                'reviewed_by' => $teacher->id,
                'previous_points' => $previousPoints,
                'new_points' => $points,
                'previous_is_correct' => $previousCorrect,
                'new_is_correct' => $newCorrect,
                'feedback' => $feedback ? trim($feedback) : null,
            ]);

            $answer->update([
                'points_earned' => round($points, 2),
                'is_correct' => $newCorrect,
                'reviewed_by' => $teacher->id,
                'reviewed_at' => now(),
                'teacher_feedback' => $feedback ? trim($feedback) : null,
            ]);

            $answers = $attempt->studentAnswers()->with('question:id,marks')->get();
            $score = (float) $answers->sum(fn ($item) => (float) ($item->points_earned ?? 0));
            $maxScore = (float) $answers->sum(fn ($item) => (float) ($item->question?->marks ?? 0));

            $pending = $answers->contains(fn ($item) => $item->points_earned === null);
            $attempt->update([
                'score' => $pending ? null : round($score, 2),
                'max_score' => round($maxScore, 2),
                'status' => $pending ? 'under_review' : 'graded',
            ]);
        });

        $attempt->refresh();
        $answer->refresh();

        return [
            'answer_id' => $answer->id,
            'points_earned' => (float) $answer->points_earned,
            'reviewed_at' => optional($answer->reviewed_at)->toDateTimeString(),
            'student_assessment_id' => $attempt->id,
            'assessment_status' => $attempt->status,
            'assessment_score' => $attempt->score === null ? null : (float) $attempt->score,
            'assessment_max_score' => (float) $attempt->max_score,
        ];
    }


    protected function learningPeriods(array $groupIds): Collection
    {
        if (empty($groupIds)) {
            return collect();
        }

        return LearningPeriod::query()
            ->whereIn('group_id', $groupIds)
            ->where('status', 'published')
            ->with([
                'group:id,group_name,grade_subject_id',
                'group.students:id,name,email',
                'gradeSubject:id,subject_id,grade_level_id',
                'gradeSubject.subject:id,name',
                'gradeSubject.gradeLevel:id,grade_name',
            ])
            ->orderByDesc('start_date')
            ->orderByDesc('id')
            ->get();
    }

    protected function periodState(LearningPeriod $period): string
    {
        $today = now()->startOfDay();
        $start = $period->start_date ? $period->start_date->copy()->startOfDay() : null;
        $end = $period->end_date ? $period->end_date->copy()->endOfDay() : null;

        if ($start && $start->gt($today)) {
            return 'upcoming';
        }

        if ($end && $end->lt($today)) {
            return 'previous';
        }

        return 'current';
    }

    protected function periodSummaries(
        Collection $periods,
        Collection $students,
        Collection $assessments,
        Collection $checks
    ): Collection {
        return $periods->map(function (LearningPeriod $period) use ($students, $assessments, $checks) {
            $periodAssessments = $assessments
                ->filter(fn ($column) => (int) ($column['learning_period_id'] ?? 0) === (int) $period->id);

            $periodChecks = $checks
                ->filter(fn ($check) => (int) ($check['learning_period_id'] ?? 0) === (int) $period->id);

            $scores = collect();
            foreach ($periodAssessments as $column) {
                foreach ($column['attempts'] as $attempt) {
                    if (!$attempt || !in_array($attempt->status, ['completed', 'graded'], true)) {
                        continue;
                    }
                    $max = (float) $attempt->max_score;
                    if ($max > 0) {
                        $scores->push(round(((float) $attempt->score / $max) * 100, 1));
                    }
                }
            }

            $groupStudents = $period->group?->students ?? collect();

            return [
                'id' => $period->id,
                'title' => $period->title,
                'group_id' => $period->group_id,
                'group_name' => $period->group?->group_name,
                'subject' => $period->gradeSubject?->subject?->name,
                'grade' => $period->gradeSubject?->gradeLevel?->grade_name,
                'start_date' => $period->start_date ? (string) $period->start_date : null,
                'end_date' => $period->end_date ? (string) $period->end_date : null,
                'period_state' => $this->periodState($period),
                'students' => $groupStudents->count(),
                'assessments' => $periodAssessments->count(),
                'assessment_average' => $this->average($scores),
                'understanding_checks' => $periodChecks->count(),
                'check_average' => $this->average($periodChecks->pluck('score')->filter(fn ($value) => $value !== null)),
            ];
        })->values();
    }

    protected function average(Collection $values): ?float
    {
        $filtered = $values->filter(fn ($value) => $value !== null && $value !== '');
        return $filtered->isEmpty() ? null : round((float) $filtered->avg(), 1);
    }

    protected function ensureTeacherOrAdmin(User $user): void
    {
        abort_unless(
            in_array($user->role, ['teacher', 'admin'], true),
            403,
            'Only teachers and administrators can access the gradebook.'
        );
    }
}
