<?php

namespace App\Services\Tutor;

use App\Models\KnowledgeChunk;
use App\Models\TutorSession;
use Illuminate\Support\Collection;

class TutorKnowledgeService
{
    public function retrieve(
        TutorSession $session,
        string $query,
        int $limit = 8
    ): Collection {
        $session->loadMissing([
            'unit',
            'topic.learningObjectives',
            'objectives.learningObjective',
        ]);

        $searchText = $this->buildSearchText($session, $query);

        $terms = $this->extractTerms($searchText);

        $base = KnowledgeChunk::query()
            ->where('status', 'ready')
            ->where('subject_id', $session->subject_id)
            ->whereHas('courseMaterial', function ($q) {
                $q->where('status', 'approved')
                    ->where('processing_status', 'completed');
            })
            ->where(function ($q) use ($session) {
                $q->where('topic_id', $session->topic_id)
                    ->orWhere('unit_id', $session->unit_id)
                    ->orWhere(function ($scope) {
                        $scope->whereNull('topic_id')
                            ->whereNull('unit_id');
                    });
            });

        $chunks = $base
            ->with([
                'courseMaterial:id,title,subject_id,unit_id,topic_id,scope',
            ])
            ->get();

        if ($chunks->isEmpty()) {
            return collect();
        }

        return $chunks
            ->map(function ($chunk) use (
                $session,
                $terms,
                $searchText
            ) {
                $score = $this->scoreChunk(
                    $chunk,
                    $session,
                    $terms,
                    $searchText
                );

                $chunk->tutor_relevance_score = $score;
                $chunk->tutor_material_scope = $this->materialScope(
                    $chunk,
                    $session
                );

                return $chunk;
            })
            ->sortByDesc('tutor_relevance_score')
            ->take(max(1, $limit))
            ->values();
    }

    protected function buildSearchText(
        TutorSession $session,
        string $query
    ): string {
        $parts = [];

        if (!empty($query)) {
            $parts[] = $query;
        }

        if ($session->topic?->topic_name) {
            $parts[] = $session->topic->topic_name;
        }

        if ($session->unit?->name) {
            $parts[] = $session->unit->name;
        }

        $objectives = $session->objectives
            ->sortBy('objective_order')
            ->filter(function ($item) {
                return !in_array(
                    strtolower((string) $item->status),
                    ['completed', 'mastered'],
                    true
                );
            })
            ->take(2)
            ->map(function ($item) {
                return $item->learningObjective?->objective;
            })
            ->filter()
            ->values()
            ->all();

        if (!empty($objectives)) {
            $parts = array_merge($parts, $objectives);
        }

        return trim(implode(' ', $parts));
    }

    protected function extractTerms(string $text): Collection
    {
        $terms = preg_split(
            '/\s+/u',
            mb_strtolower($text),
            -1,
            PREG_SPLIT_NO_EMPTY
        ) ?: [];

        return collect($terms)
            ->map(function ($term) {
                return preg_replace(
                    '/[^\pL\pN]+/u',
                    '',
                    $term
                );
            })
            ->filter(function ($term) {
                return mb_strlen($term) >= 3;
            })
            ->unique()
            ->values();
    }
    protected function scoreChunk(
        $chunk,
        TutorSession $session,
        Collection $terms,
        string $searchText
    ): int {
        $content = mb_strtolower((string) $chunk->content);

        $score = 0;

        if ((int) $chunk->topic_id === (int) $session->topic_id) {
            $score += 100;
        }

        if (!empty($chunk->unit_id) && (int) $chunk->unit_id === (int) $session->unit_id) {
            $score += 50;
        }

        if (is_null($chunk->topic_id) && is_null($chunk->unit_id)) {
            $score += 15;
        }

        foreach ($terms as $term) {
            $occurrences = substr_count($content, $term);

            if ($occurrences > 0) {
                $score += min($occurrences, 6) * 3;
            }
        }

        $normalizedSearch = trim(
            preg_replace(
                '/\s+/u',
                ' ',
                mb_strtolower($searchText)
            )
        );

        if (
            $normalizedSearch !== '' &&
            mb_strlen($normalizedSearch) >= 8 &&
            str_contains($content, $normalizedSearch)
        ) {
            $score += 25;
        }

        $material = $chunk->courseMaterial;

        if ($material) {

            if ((int) $material->topic_id === (int) $session->topic_id) {
                $score += 30;
            }
            if (!empty($material->unit_id) && (int) $material->unit_id === (int) $session->unit_id) {
                $score += 15;
            }
        }

        return $score;
    }
    protected function materialScope(
        $chunk,
        TutorSession $session
    ): string {
        if ((int) $chunk->topic_id === (int) $session->topic_id) {
            return 'topic';
        }

        if (
            !empty($chunk->unit_id) &&
            (int) $chunk->unit_id ===
            (int) $session->unit_id
        ) {
            return 'unit';
        }

        return 'subject';
    }
}