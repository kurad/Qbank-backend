<?php

namespace App\Services\Tutor;

use App\Models\TutorSession;
use App\Models\TutorSessionObjective;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class TutorSessionService
{
    public function __construct(
        protected TutorContextService $context,
        protected TutorAIService $ai
    ) {}

    /**
     * Create a guided Tutor session.
     *
     * Student selects:
     *
     * Class → Learning Period → Topic
     *
     * Subject is still supplied by the UI but is validated
     * against the LearningPeriod.
     *
     * Unit is resolved from the scheduled period topic.
     *
     * ALL active objectives are automatically attached.
     */
    public function create(
        User $student,
        array $data
    ): TutorSession {
        $resolved = $this->context->resolveSessionContext(
            $student,
            $data
        );

        $objectives = $resolved['objectives'] ?? collect();

        if ($objectives->isEmpty()) {
            throw ValidationException::withMessages([
                'topic_id' =>
                    'The selected topic does not have any active learning objectives.',
            ]);
        }

        $session = DB::transaction(function () use (
            $student,
            $resolved,
            $objectives
        ) {
            $now = now();

            $session = TutorSession::create([
                'student_id' => $student->id,

                'group_id' =>
                    $resolved['group']->id,

                'learning_period_id' =>
                    $resolved['learningPeriod']->id,

                'grade_subject_id' =>
                    $resolved['gradeSubject']->id,

                'subject_id' =>
                    $resolved['gradeSubject']->subject_id,

                'unit_id' =>
                    $resolved['unit']->id,

                'topic_id' =>
                    $resolved['topic']->id,

                // Kept nullable for backward compatibility.
                'learning_objective_id' => null,

                'title' =>
                    $resolved['topic']->topic_name,

                'status' => 'active',

                'started_at' => $now,

                'last_activity_at' => $now,
            ]);

            foreach (
                $objectives
                    ->sortBy('order')
                    ->values()
                    as $index => $objective
            ) {
                $isFirst = $index === 0;

                $session->objectives()->create([
                    'learning_objective_id' =>
                        $objective->id,

                    'objective_order' =>
                        $index + 1,

                    'status' =>
                        $isFirst
                            ? 'in_progress'
                            : 'not_started',

                    'started_at' =>
                        $isFirst
                            ? $now
                            : null,

                    'completed_at' => null,

                    'attempts' => 0,

                    'correct_attempts' => 0,

                    'notes' => null,
                ]);
            }

            return $session;
        });

        /*
         * Start the lesson immediately.
         */
        $opening = $this->ai->opening($session);

        $session->messages()->create([
            'role' => 'assistant',
            'message_type' => 'opening',
            'content' => $opening,
        ]);

        $session->update([
            'last_activity_at' => now(),
        ]);

        return $this->freshSession($session);
    }

    /**
     * Current unfinished objective.
     */
    public function currentObjective(
        TutorSession $session
    ): ?TutorSessionObjective {
        $session->loadMissing(
            'objectives.learningObjective'
        );

        return $session
            ->objectives
            ->sortBy('objective_order')
            ->first(function ($objective) {
                return !in_array(
                    strtolower(
                        (string) $objective->status
                    ),
                    [
                        'completed',
                        'mastered',
                    ],
                    true
                );
            });
    }

    /**
     * Next objective.
     */
    public function nextObjective(
        TutorSession $session,
        TutorSessionObjective $current
    ): ?TutorSessionObjective {
        return $session
            ->objectives
            ->sortBy('objective_order')
            ->first(function ($objective) use ($current) {
                return (int) $objective->objective_order >
                    (int) $current->objective_order;
            });
    }

    /**
     * Finish a Tutor session manually.
     */
    public function finish(
        User $student,
        TutorSession $session,
        string $status = 'completed'
    ): TutorSession {
        abort_unless(
            (int) $session->student_id ===
            (int) $student->id,
            403
        );

        abort_unless(
            in_array(
                $status,
                ['completed', 'abandoned'],
                true
            ),
            422
        );

        $session->update([
            'status' => $status,
            'ended_at' => now(),
            'last_activity_at' => now(),
        ]);

        return $this->freshSession($session);
    }

    protected function freshSession(
        TutorSession $session
    ): TutorSession {
        return $session
            ->fresh()
            ->load([
                'group:id,group_name,class_code',

                'learningPeriod:id,group_id,grade_subject_id,title,description,start_date,end_date,status',

                'gradeSubject.subject:id,name',

                'gradeSubject.gradeLevel:id,grade_name',

                'unit:id,name',

                'topic:id,topic_name',

                'objectives.learningObjective:id,topic_id,code,objective,description,order,status',

                'messages:id,tutor_session_id,role,message_type,content,created_at',
            ]);
    }
}