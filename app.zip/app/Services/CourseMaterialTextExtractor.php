<?php

namespace App\Services;

use App\Models\CourseMaterial;
use App\Models\CourseMaterialPage;
use App\Models\CourseMaterialVisual;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Imagick;
use Log;
use RuntimeException;
use Smalot\PdfParser\Parser;

class CourseMaterialTextExtractor
{

    public function extract(CourseMaterial $material): array
    {
        // PDF processing can take several minutes for large curriculum PDFs.
        set_time_limit(0);
        ini_set('max_execution_time', '0');
        
        Log::info('PDF EXTRACTION STARTED', [
            'material_id' => $material->id,
            'file_name' => $material->file_name,
            'original_file_path' => $material->original_file_path,
        ]);

        $path = $this->resolveStoredPath(
            $material->original_file_path
        );

        \Log::info('PDF PATH RESOLVED', [
            'material_id' => $material->id,
            'path' => $path,
            'exists' => is_file($path),
            'size' => is_file($path) ? filesize($path) : null,
        ]);

        if (!is_file($path)) {
            throw new RuntimeException(
                'The stored course-material file could not be found.'
            );
        }

        if (!extension_loaded('imagick')) {
            throw new RuntimeException(
                'The PHP Imagick extension is required to process PDF pages.'
            );
        }

        \Log::info('IMAGICK AVAILABLE', [
            'material_id' => $material->id,
            'imagick' => extension_loaded('imagick'),
            'version' => (new \Imagick())->getVersion()['versionString'] ?? null,
        ]);

        /*
    |--------------------------------------------------------------------------
    | PDF TEXT PARSING
    |--------------------------------------------------------------------------
    */

        \Log::info('PDF PARSER STARTING', [
            'material_id' => $material->id,
        ]);

        $parser = new Parser();

        $pdf = $parser->parseFile($path);

        \Log::info('PDF PARSER FINISHED', [
            'material_id' => $material->id,
        ]);

        $pages = $pdf->getPages();

        \Log::info('PDF PAGES READ', [
            'material_id' => $material->id,
            'page_count' => count($pages),
        ]);

        $pageData = [];

        foreach ($pages as $index => $page) {
            $pageNumber = $index + 1;

            \Log::info('EXTRACTING PAGE TEXT', [
                'material_id' => $material->id,
                'page' => $pageNumber,
            ]);

            $text = trim(
                preg_replace(
                    '/\s+/u',
                    ' ',
                    $page->getText()
                ) ?? ''
            );

            $pageData[] = [
                'page_number' => $pageNumber,
                'text' => $text,
            ];
        }

        \Log::info('ALL PAGE TEXT EXTRACTED', [
            'material_id' => $material->id,
        ]);

        $completeText = collect($pageData)
            ->map(fn($page) => $page['text'])
            ->filter()
            ->implode("\n\n");

        $completeText = trim($completeText);

        if ($completeText === '') {
            throw new RuntimeException(
                'No readable text was found in the PDF.'
            );
        }

        /*
    |--------------------------------------------------------------------------
    | IMAGE RENDERING
    |--------------------------------------------------------------------------
    */

        \Log::info('STARTING PDF PAGE RENDERING', [
            'material_id' => $material->id,
            'page_count' => count($pages),
        ]);

        $renderedPages = $this->renderPages(
            $path,
            $material->id,
            count($pages)
        );

        \Log::info('PDF PAGE RENDERING FINISHED', [
            'material_id' => $material->id,
            'visual_count' => count($renderedPages),
        ]);

        /*
    |--------------------------------------------------------------------------
    | SAVE PAGE DATA
    |--------------------------------------------------------------------------
    */

        DB::transaction(function () use (
            $material,
            $pageData,
            $renderedPages
        ) {
            \Log::info('SAVING PDF PAGE RECORDS', [
                'material_id' => $material->id,
                'page_count' => count($pageData),
            ]);

            $material->pages()
                ->each(function ($page) {
                    $page->visuals()->delete();
                    $page->delete();
                });

            foreach ($pageData as $page) {
                $pageModel = CourseMaterialPage::create([
                    'course_material_id' => $material->id,
                    'page_number' => $page['page_number'],
                    'text' => $page['text'] ?: null,
                    'metadata' => [
                        'source' => 'pdf',
                    ],
                ]);

                if (isset($renderedPages[$page['page_number']])) {
                    $rendered = $renderedPages[$page['page_number']];

                    CourseMaterialVisual::create([
                        'course_material_id' =>
                        $material->id,

                        'course_material_page_id' =>
                        $pageModel->id,

                        'type' => 'page_snapshot',

                        'file_path' =>
                        $rendered['path'],

                        'file_name' =>
                        $rendered['file_name'],

                        'mime_type' =>
                        'image/png',

                        'caption' =>
                        'PDF page ' .
                            $page['page_number'],

                        'metadata' => [
                            'page_number' =>
                            $page['page_number'],

                            'source' =>
                            'pdf-render',
                        ],

                        'sort_order' => 1,
                    ]);
                }
            }

            \Log::info('PDF PAGE RECORDS SAVED', [
                'material_id' => $material->id,
            ]);
        });

        \Log::info('PDF EXTRACTION COMPLETED', [
            'material_id' => $material->id,
            'page_count' => count($pageData),
            'visual_count' => count($renderedPages),
        ]);

        return [
            'text' => $completeText,
            'page_count' => count($pageData),
            'visual_count' => count($renderedPages),
            'pages' => $pageData,
        ];
    }

    /**
     * Render PDF pages as PNG images.
     *
     * Returns:
     *
     * [
     *     1 => [
     *         'path' => '...',
     *         'file_name' => '...'
     *     ]
     * ]
     */
    protected function renderPages(
        string $pdfPath,
        int $materialId,
        int $pageCount
    ): array {
        $results = [];

        $directory =
            'course-material-assets/' .
            $materialId .
            '/pages';

        /*
        |--------------------------------------------------------------------------
        | Remove previously generated page images
        |--------------------------------------------------------------------------
        */

        $existingFiles = Storage::disk('local')
            ->files($directory);

        if (!empty($existingFiles)) {
            Storage::disk('local')
                ->delete($existingFiles);
        }

        /*
        |--------------------------------------------------------------------------
        | Render each page
        |--------------------------------------------------------------------------
        */

        for ($page = 1; $page <= $pageCount; $page++) {

            \Log::info('RENDERING PDF PAGE START', [
                'material_id' => $materialId,
                'page' => $page,
                'page_count' => $pageCount,
            ]);

            $image = new Imagick();

            try {
                $image->setResolution(150, 150);

                \Log::info('IMAGICK READING PAGE', [
                    'material_id' => $materialId,
                    'page' => $page,
                ]);

                $image->readImage(
                    $pdfPath . '[' . ($page - 1) . ']'
                );

                \Log::info('IMAGICK READ PAGE SUCCESS', [
                    'material_id' => $materialId,
                    'page' => $page,
                ]);

                $image->setImageFormat('png');
                $image->setImageBackgroundColor('white');

                if (method_exists($image, 'setImageAlphaChannel')) {
                    $image->setImageAlphaChannel(
                        Imagick::ALPHACHANNEL_REMOVE
                    );
                }

                $image->stripImage();

                $fileName =
                    'page-' .
                    str_pad(
                        (string) $page,
                        4,
                        '0',
                        STR_PAD_LEFT
                    ) .
                    '.png';

                $relativePath =
                    $directory . '/' . $fileName;

                Storage::disk('local')->put(
                    $relativePath,
                    $image->getImageBlob()
                );

                \Log::info('PDF PAGE SAVED', [
                    'material_id' => $materialId,
                    'page' => $page,
                    'path' => $relativePath,
                ]);

                $results[$page] = [
                    'path' => $relativePath,
                    'file_name' => $fileName,
                ];
            } finally {
                $image->clear();
                $image->destroy();

                \Log::info('RENDERING PDF PAGE FINISHED', [
                    'material_id' => $materialId,
                    'page' => $page,
                ]);
            }
        }

        return $results;
    }

    /**
     * Resolve the stored course material path.
     */
    private function resolveStoredPath(
        string $relativePath
    ): string {
        $configuredRoot =
            config(
                'filesystems.disks.local.root',
                storage_path('app')
            );

        $configuredPath =
            rtrim(
                $configuredRoot,
                DIRECTORY_SEPARATOR
            )
            . DIRECTORY_SEPARATOR
            . ltrim(
                $relativePath,
                DIRECTORY_SEPARATOR
            );

        if (is_file($configuredPath)) {
            return $configuredPath;
        }

        $privatePath =
            storage_path(
                'app/private/' .
                    ltrim(
                        $relativePath,
                        DIRECTORY_SEPARATOR
                    )
            );

        if (is_file($privatePath)) {
            return $privatePath;
        }

        throw new RuntimeException(
            'The stored course-material file could not be found.'
        );
    }
}
